Drop custom .ogg files here:
  sounds/pipe/<name>
Slots: steam_hiss, gas_leak, valve_open, valve_close, tap_fill
