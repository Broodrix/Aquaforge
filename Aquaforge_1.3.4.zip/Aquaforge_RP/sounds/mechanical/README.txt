Drop custom .ogg files here and point sound_definitions.json paths to:
  sounds/mechanical/<name>
Slots: gears_turning, clutch_engage, wheel_creak, turbine_whir
