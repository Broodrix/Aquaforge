# Aquaforge

A lightweight Minecraft Bedrock engineering addon focused exclusively on **mechanical power, water power and steam/pressure power**.

## Target
- Minecraft Bedrock v1.26.33
- `@minecraft/server` 2.8.0
- `@minecraft/server-ui` 2.1.0

## Progression
**Mechanical → Water → Steam**

1. Hand Crank / shafts / gearbox / mechanical mill
2. Water Wheel / pump / water pipes / tanks / hydraulic turbine / hydraulic press
3. Boiler / steam pipes / steam tank / pressure regulator / steam engine / steam hammer / condenser

## Architecture
- Server-authoritative simulation.
- Block-entity dynamic properties for per-machine and tank state.
- Small BFS fluid/mechanical networks with a hard node limit.
- No `.mcfunction` tick loops.
- 10-tick simulation cadence.
- UI only opens on interaction; no permanent UI overlay.

## Important
This package has been syntax/structure validated before delivery, but **has not been run inside Minecraft in this environment**.
