# Aquaforge — Changelog

## [1.3.4] - 2026-10-13
### Fixed
- Restored **exact large** water_wheel (27-cube paddles), windmill (sails), water_turbine geos — no more compacted stand-ins.
- Machine blocks use multi-face materials: front_off / side / top / bottom from FINAL_TEXTURES.
- Water wheel / windmill / turbine / pump textures mapped to correct asset files (no black models).
- Pipe bone_visibility: `query.block_state(...) == 1.0` for reliable face arms.
- Full FINAL_TEXTURES overlay (blocks + items + fluids + gasses).
- Terrain atlas rebuilt (96 keys) from live block material refs.

### Preserved
- Face-state pipe/shaft permutations, energy networks, universal tanks.

## [1.3.3] - 2026-10-13
### Fixed
- Pipe connections: hardened connector (change-only permutation, triple deferred refresh 0/1/3 ticks), Molang `query.block_state` bone_visibility (no `== true`).
- `water_wheel` geometry: removed oversized `mechanical_water_wheel_large` (27 OOB cubes, duplicate id) — was causing bounds error + tessellation failure.
- Pressure gauge: full_block with multi-face materials (`pressure_gauge_front/side/top/bottom`).
- Glass fluid tank: top face uses `glass_fluid_tank_top`.
- Removed unused block textures (`*_texture.png` duplicates, animated placeholders).
- Removed unused placeholder item textures; icons alias to iron_* / turbine assets.
- Terrain + item atlases cleaned.

### Preserved
- Face-state permutations on all transport pipes/shafts.
- Universal tanks, fluid/steam/gas networks, energy simulation.

## [1.3.3] - 2026-10-13
### Fixed
- Pipe connections: hardened connector (change-only permutation, triple deferred refresh 0/1/3 ticks), Molang `query.block_state` bone_visibility (no `== true`).
- `water_wheel` geometry: removed oversized `mechanical_water_wheel_large` (27 OOB cubes, duplicate id) — was causing bounds error + tessellation failure.
- Pressure gauge: full_block with multi-face materials (`pressure_gauge_front/side/top/bottom`).
- Glass fluid tank: top face uses `glass_fluid_tank_top`.
- Removed unused block textures (`*_texture.png` duplicates, animated placeholders).
- Removed unused placeholder item textures; icons alias to iron_* / turbine assets.
- Terrain + item atlases cleaned.

### Preserved
- Face-state permutations on all transport pipes/shafts.
- Universal tanks, fluid/steam/gas networks, energy simulation.


## [1.3.1] - 2026-10-13
### Fixed
- Recipe unlock data on all 1.20+ shaped recipes (fluid_pipe, glass_fluid_pipe, tanks).
- `fluid_tap` bone_visibility: removed invalid `handle_off`/`handle_on` (geo only has `handle`).
- `windmill` geometry: compacted sails/hub within Bedrock error bounds (was 6 oversized boxes).
- Replaced placeholder block textures (gearbox, hand_crank, mechanical_mill) with asset UV sides.
- Machine textures mapped from multi-face asset sets (boiler, condenser, press, engine, hammer).
- Item texture atlas rebuilt from AquaForge_Assets (82 keys); item icons aligned.
- Removed `textures/blocks/phase4` unused folder.

### Added
- Full asset overlay: geos + block UV + item textures from AquaForge_Assets.zip.
- Fluid/gasses stills retained under textures/blocks/fluids and gasses.

### Preserved
- Face-state permutations + Molang bone_visibility on all transport pipes/shafts.
- Universal tanks 16 000 mB, pressure tiers, network sets.

## [1.3.0] - 2026-10-13
### Added
- Universal tanks: `copper_tank`, `iron_tank`, `steel_tank`, `glass_fluid_tank` — each 16 000 mB (16 buckets).
  - Pressure tiers: copper 8 bar · iron 12 bar · steel 20 bar · glass 4 bar.
  - All metal tanks accept fluid, steam, and gas networks.
- `fluid_pipe` (renamed from water_pipe) + `glass_fluid_pipe` for liquid transport.
- New geo models: fluid_pipe, glass_fluid_pipe, gas_pipe, steam_pipe, mechanical_shaft, valves, pumps, turbines (normalized to `geometry.aquaforge_*`).
- Fluid stills under `textures/blocks/fluids/` and gas stills under `textures/blocks/gasses/`.
- Full tank UV set (level fronts 1–8, empty, top, bottom, side) for copper / iron / steel / glass.

### Changed
- `water_pipe` → `fluid_pipe` (identifier, recipes, catalog, connector, networks).
- Network sets WATER / STEAM / GAS now route through universal tanks.
- Tank UI bars use 16 000 mB capacity.
- Terrain atlas expanded (74 keys) for new transport + fluid/gas textures.

### Removed
- `water_tank` and `steam_tank` (replaced by tiered universal tanks).

### Preserved
- Face-state permutations + Molang bone_visibility for all transport blocks.
- Energy simulation cadence, network cache, and mechanical bridge unchanged.


## [0.1.36] - 2026-09-29 (Daturion suite 1.2.16)
### Fixed
- Recipe collisions:
  - `iron_plate` / `copper_plate`: 3-in-a-row (no longer mirror iron/copper trapdoor 2×2).
  - `spring`: diagonal steel_rod pattern (distinct from vertical `steel_bolt`).
  - `gasket`: copper_plate + leather + string (distinct from `seal`).
- Component items category aligned to `construction`.

