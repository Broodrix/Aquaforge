# Aquaforge v0.17 --- Complete Architecture & Stability Audit

> **Target:** Minecraft Bedrock 1.26.33 Android\
> **Declared API:** `@minecraft/server` 2.8.0 + `@minecraft/server-ui`
> 2.1.0\
> **Audit:** static inspection of the supplied `AquaForge_v0.17.zip`\
> **Testing boundary:** no in-game or multiplayer execution was
> performed during this audit.

## Executive verdict

Aquaforge has a **good lightweight engineering architecture**, but it is
currently a **prototype/skeleton rather than a stable multiplayer
release**.

The strongest parts are:

-   server-side simulation;
-   10-tick processing cadence;
-   bounded BFS;
-   network caching;
-   dirty-network invalidation;
-   explicit Mechanical / Water / Steam domains;
-   compact Datura bridge;
-   very small content footprint.

The largest problem is functional rather than cosmetic:

> **`data.json` contains machine recipes, but `main.js` does not execute
> those recipes.**

The current machine code can determine that a machine has enough power
and set `active = 1`, but it does not actually implement:

``` text
INPUT
  ↓
RECIPE
  ↓
POWER PAYMENT
  ↓
PROGRESS
  ↓
OUTPUT
```

That is the next development priority.

------------------------------------------------------------------------

# 1. Package inventory

  Asset                                Count
  ---------------------------------- -------
  Behavior Pack blocks                    17
  Custom items                             6
  Crafting recipes                        20
  Block loot tables                       17
  Parsed JSON files                       68
  JSON parse errors                        0
  Missing block texture references         0
  Missing block loot references            0

## Block identifiers

  Identifier
  --------------------------------
  `aquaforge:boiler`
  `aquaforge:condenser`
  `aquaforge:gearbox`
  `aquaforge:hand_crank`
  `aquaforge:hydraulic_press`
  `aquaforge:mechanical_mill`
  `aquaforge:pressure_regulator`
  `aquaforge:shaft`
  `aquaforge:steam_engine`
  `aquaforge:steam_hammer`
  `aquaforge:steam_pipe`
  `aquaforge:steam_tank`
  `aquaforge:water_pipe`
  `aquaforge:water_pump`
  `aquaforge:water_tank`
  `aquaforge:water_turbine`
  `aquaforge:water_wheel`

## Custom items

  Identifier
  ---------------------------
  `aquaforge:control_panel`
  `aquaforge:flour`
  `aquaforge:iron_plate`
  `aquaforge:machine_frame`
  `aquaforge:steel_plate`
  `aquaforge:valve_core`

------------------------------------------------------------------------

# 2. Complete architecture

``` text
Minecraft Bedrock
       │
       ▼
Aquaforge Behavior Pack
       │
       ├── scripts/main.js
       │     ├── node registry
       │     ├── BFS network discovery
       │     ├── network cache
       │     ├── dirty invalidation
       │     ├── mechanical simulation
       │     ├── water/steam state
       │     ├── machine activation
       │     ├── interaction handling
       │     └── UI
       │
       ├── scripts/datura_bridge.js
       │     └── cross-pack protocol
       │
       ├── data.json
       │     └── machine definitions
       │
       ├── blocks/
       ├── items/
       ├── recipes/
       └── loot_tables/

Aquaforge Resource Pack
       ├── terrain textures
       ├── item textures
       ├── language
       └── UI
```

## Runtime pipeline

``` text
Block placed
   ↓
NODE registration
   ↓
dirty network
   ↓
bounded BFS
   ↓
cached network
   ↓
10-tick simulation
   ↓
sources / tanks / machines
```

This is a sensible Bedrock architecture.

The problem is that the graph/network layer is currently more complete
than the actual machine-processing layer.

------------------------------------------------------------------------

# 3. Current progression

``` text
MECHANICAL
   │
   ├── Hand Crank
   ├── Shaft
   ├── Gearbox
   └── Mechanical Mill
          │
          ▼
WATER
   │
   ├── Water Wheel
   ├── Water Pump
   ├── Water Pipe
   ├── Water Tank
   ├── Water Turbine
   └── Hydraulic Press
          │
          ▼
STEAM
   │
   ├── Boiler
   ├── Steam Pipe
   ├── Steam Tank
   ├── Pressure Regulator
   ├── Steam Engine
   ├── Steam Hammer
   └── Condenser
```

The progression concept is good.

Do not expand the tree until these three levels are functionally
complete.

------------------------------------------------------------------------

# 4. Machine registry audit

`data.json` contains exactly three machine definitions:

  Machine           Power          Cost       Time Input        Output
  ----------------- ------------ ------ ---------- ------------ -------------
  Mechanical Mill   mechanical        2   40 ticks Wheat        Flour
  Hydraulic Press   water             3   30 ticks Iron Ingot   Iron Plate
  Steam Hammer      steam             4   24 ticks Iron Ingot   Steel Plate

## Critical finding

`main.js` does not import/read `data.json`.

Therefore the registry is currently **documentation/configuration**, not
an active runtime recipe system.

This is the single most important functional gap.

------------------------------------------------------------------------

# 5. Machine-processing bugs

The current powered-machine logic effectively does:

``` js
const { power } = getMechanical(dim, { x, y, z });

if (power >= 4) {
    setDP(b, "active", 1);
} else {
    setDP(b, "active", 0);
}
```

There is no runtime implementation for:

-   input inventory;
-   output inventory;
-   recipe lookup;
-   processing progress;
-   power payment;
-   input consumption;
-   output creation;
-   output-full blocking;
-   completion state.

Therefore:

**Mechanical Mill:** does not actually convert wheat into flour.

**Hydraulic Press:** does not actually convert iron ingots into iron
plates.

**Steam Hammer:** does not actually convert iron ingots into steel
plates.

The addon currently has powered machine **activation**, not powered
machine **processing**.

------------------------------------------------------------------------

# 6. Power-system problem

The current mechanical network calculates total source output.

It does not properly allocate that output between consumers.

Example:

``` text
Source = 10 torque

Machine A = 4
Machine B = 4
Machine C = 4

Total demand = 12
Total supply = 10
```

The current architecture can allow all three machines to see the same
network power.

There is no authoritative:

``` text
supply → allocation → consumption
```

transaction.

## Required model

``` text
TOTAL SUPPLY
      ↓
TOTAL DEMAND
      ↓
DETERMINISTIC ALLOCATION
      ↓
MACHINE POWER PAYMENT
      ↓
PROCESS
```

This is mandatory for multiplayer correctness.

------------------------------------------------------------------------

# 7. Water-system audit

Current water nodes:

``` text
water_pipe
water_tank
water_pump
water_turbine
boiler
hydraulic_press
condenser
```

The network can discover connected water nodes.

However, the actual fluid transfer system is incomplete.

A water bucket can manually add 1000 mB to a water tank.

The `water_pump` does not implement a real transfer operation.

## Recommended minimal water engine

Do not simulate individual fluid particles.

Use:

``` text
Tank volume
+
Network connectivity
+
Pump rate
+
Consumer demand
=
abstract flow
```

That is dramatically cheaper and sufficient for gameplay.

------------------------------------------------------------------------

# 8. Steam-system audit

Current boiler behavior is essentially:

``` text
10 water
   ↓
8 steam
```

Steam engine behavior:

``` text
5 steam
   ↓
12 mechanical output
```

This is a good lightweight abstraction.

However, the current system lacks complete:

-   steam transfer;
-   pressure regulation;
-   condenser operation;
-   flow direction;
-   pressure loss;
-   machine demand;
-   overpressure state.

## Recommended model

Use:

``` text
steam amount
pressure
network capacity
consumer demand
```

Do not implement particle simulation.

------------------------------------------------------------------------

# 9. Missing pressure-regulator implementation

`pressure_regulator` exists as a block and recipe, but the runtime has
no corresponding simulation branch.

Recommended behavior:

``` text
pressure > configured limit
        ↓
restrict steam transfer
        ↓
prevent downstream overpressure
```

A simple fixed pressure threshold is enough.

------------------------------------------------------------------------

# 10. Missing condenser implementation

`condenser` exists but currently has no actual processing logic.

Minimal behavior:

``` text
steam
  ↓
condenser
  ↓
water
```

Use a fixed conversion rate.

Do not build a thermodynamic simulator.

------------------------------------------------------------------------

# 11. Missing water-pump implementation

The pump is registered as a node but does not actually transfer water.

Recommended:

``` text
pump
 ↓
find source
 ↓
find connected destination
 ↓
check capacity
 ↓
move fixed mB
```

The transfer should happen only when a valid connected network exists.

------------------------------------------------------------------------

# 12. Persistence architecture is incomplete

The code contains:

``` js
loadState()
saveState()
```

but the runtime does not actually perform a proper load/save lifecycle.

This means the apparent persistent-state architecture does not match the
implementation.

There is an additional serious problem:

``` js
JSON.stringify(obj).slice(0, 9000)
```

Never truncate serialized JSON.

It can create:

``` text
valid JSON
   ↓
slice
   ↓
invalid JSON
   ↓
JSON.parse failure
```

There is also a hard:

``` js
if (n >= 256) break;
```

which silently limits stored state.

## Correct direction

Prefer machine-local state for machine-local data.

Modern Bedrock documentation provides block dynamic-property support for
block entities and documents its storage behavior. That model is much
closer to Aquaforge's desired machine-state architecture than a single
giant world JSON blob. citeturn1search2turn1search4

If the exact block-local API required is not suitable for the declared
2.8.0 target, use a bounded world-state fallback with:

-   schema version;
-   validated length;
-   no truncation;
-   migration;
-   deterministic recovery.

------------------------------------------------------------------------

# 13. NODE registry performance

Every 100 ticks, each player causes a scan of:

``` text
dy = 5
dx = 13
dz = 13

5 × 13 × 13 = 845 block reads/player
```

Therefore:

``` text
1 player  ≈ 845 reads
10 players ≈ 8,450 reads
```

per discovery pass.

This is not automatically catastrophic, but it is unnecessary as the
normal discovery mechanism.

You already have:

``` text
playerPlaceBlock
playerBreakBlock
```

Therefore use events as the primary registry.

Use the radius scan only as an occasional recovery mechanism.

------------------------------------------------------------------------

# 14. Distant-network pruning bug

`pruneStaleNodes()` can remove nodes simply because they are far from
all players when the node cap is reached.

That can produce:

``` text
Player leaves factory
        ↓
Factory becomes distant
        ↓
Nodes become prune candidates
        ↓
Simulation state disappears
```

This is not safe for persistent multiplayer factories.

## Correct design

Distance should control **simulation frequency**, not authoritative
existence.

``` text
Nearby network
 → normal simulation

Distant network
 → sleeping / low-frequency simulation

Persisted network
 → state retained
```

Never delete authoritative machine state merely because a player moved
away.

------------------------------------------------------------------------

# 15. 96-node network limit

The BFS has a hard limit of 96 nodes.

That is good for Android safety.

The problem is silent partial simulation.

A 150-node network can be treated as the first 96 nodes.

## Required behavior

``` text
Network ≤ 96
     ↓
NORMAL

Network > 96
     ↓
OVERLOAD
     ↓
simulation paused
```

Display:

``` text
NETWORK OVERLOAD
Maximum safe size: 96
Current size: 117
```

Never silently simulate a partial network.

------------------------------------------------------------------------

# 16. Network-cache architecture

Current cache keys are based on the network starting position.

Therefore one physical network can have multiple cache entries:

``` text
Network A from seed 1
Network A from seed 2
Network A from seed 3
```

This is acceptable at the current small scale.

Later, canonicalize:

``` text
BFS
 ↓
collect node keys
 ↓
sort
 ↓
first key = canonical network ID
```

This is a P1 optimization.

Do not spend development time on it before machine processing works.

------------------------------------------------------------------------

# 17. Water-wheel abstraction

The current water wheel determines strength from adjacent vanilla water
blocks.

This is lightweight.

It is not full hydraulic physics.

It does not model:

-   water direction;
-   pressure head;
-   intake;
-   outlet;
-   pump flow;
-   blockage.

That is acceptable for the current prototype.

Define it clearly as:

> **Water adjacency power abstraction**

rather than a full hydraulic simulation.

------------------------------------------------------------------------

# 18. Machine-state architecture

Keep state tiny:

``` text
machine
 ├── progress
 ├── active
 ├── blocked
 └── optional buffer
```

Do not store redundant calculated values such as:

``` text
power
networkPower
hasPower
canRun
activePower
powered
```

Calculate those from the authoritative network.

------------------------------------------------------------------------

# 19. Recommended machine engine

A compact registry is enough:

``` js
const MACHINES = {
    mechanical_mill: {
        network: "mechanical",
        cost: 2,
        ticks: 40,
        input: "minecraft:wheat",
        output: "aquaforge:flour"
    },

    hydraulic_press: {
        network: "mechanical",
        cost: 3,
        ticks: 30,
        input: "minecraft:iron_ingot",
        output: "aquaforge:iron_plate"
    },

    steam_hammer: {
        network: "steam",
        cost: 4,
        ticks: 24,
        input: "minecraft:iron_ingot",
        output: "aquaforge:steel_plate"
    }
};
```

Then:

``` text
machine
 ↓
recipe
 ↓
input check
 ↓
output capacity check
 ↓
power check
 ↓
power payment
 ↓
progress
 ↓
completion
 ↓
input consumption
 ↓
output
```

All of this must be server-authoritative.

------------------------------------------------------------------------

# 20. Multiplayer transaction rules

Two players must never be able to manipulate the same machine into
duplication/loss.

The server must own:

-   inventory;
-   recipe;
-   progress;
-   power;
-   output;
-   machine state.

Never trust client/UI state.

The operation must be atomic from the gameplay perspective:

``` text
validate
 ↓
reserve/consume
 ↓
process
 ↓
commit
```

If output is full:

``` text
DO NOT consume input.
```

If power is insufficient:

``` text
DO NOT consume input.
```

If the recipe is invalid:

``` text
DO NOTHING.
```

------------------------------------------------------------------------

# 21. Recommended machine states

Use only:

  State        Meaning
  ------------ ----------------------------
  `IDLE`       No work
  `RUNNING`    Processing
  `STARVED`    Missing input/power
  `BLOCKED`    Output unavailable
  `OVERLOAD`   Network exceeds safe limit
  `ERROR`      Invalid/corrupt state

This is enough for both UI and debugging.

------------------------------------------------------------------------

# 22. Scheduler

Use multiple frequencies:

``` text
20 TPS
 └── event handling only

10 TPS
 └── active machine processing

1–2 TPS
 └── topology/recovery work

block change
 └── dirty network

player interaction
 └── UI/input
```

This is better for Android than continuously simulating every pipe.

------------------------------------------------------------------------

# 23. Active-machine scheduling

Instead of iterating every registered machine every 10 ticks:

``` text
ACTIVE_MACHINES
ACTIVE_NETWORKS
DIRTY_NETWORKS
```

Only machines that actually have work should enter the active queue.

``` text
IDLE
 ↓
input arrives
 ↓
ACTIVE
 ↓
power available?
 ├─ no → sleep
 └─ yes → process
             ↓
         complete
             ↓
           IDLE
```

This is one of the highest-value performance improvements.

------------------------------------------------------------------------

# 24. Datura bridge review

`datura_bridge.js` is a strong design choice.

It provides:

-   capability discovery;
-   pack announcement;
-   lightweight events;
-   no hard import of Datura Core.

Bedrock documents `sendScriptEvent()` / `scriptEventReceive` as the
script-event communication mechanism. citeturn1search12turn1search1

Recommended capabilities:

``` text
mechanical_power
water_flow
steam_pressure
machine_status
network_status
```

Script events should be notifications, not the authoritative database.

------------------------------------------------------------------------

# 25. Datura duplication

`datura_bridge.js` contains:

``` text
announcePack()
hasCapability()
emitDatura()
onDatura()
```

But `main.js` manually duplicates the pack announcement/protocol logic.

That creates two protocol implementations.

Make the bridge the single protocol layer.

Recommended:

``` js
announcePack(
    "aquaforge",
    VERSION,
    ["power", "mechanical", "steam"]
);
```

This reduces future compatibility problems.

------------------------------------------------------------------------

# 26. Technology-tree gates

The current:

``` text
Hand Crank
    ↓
Water Power
    ↓
Steam Power
```

is a good modular progression.

However, the current gate lookup fails open if the Datura state is
absent or malformed.

That means:

``` text
Core missing/corrupt
       ↓
gate can disappear
       ↓
technology becomes unlocked
```

For standalone compatibility, fail-open is understandable.

For deterministic progression, distinguish:

``` text
CORE_ABSENT
CORE_PRESENT_LOCKED
CORE_PRESENT_UNLOCKED
CORE_INVALID
```

Only explicit `UNLOCKED` should grant progression.

------------------------------------------------------------------------

# 27. UI

The current UI is appropriately small.

Keep it small.

Recommended machine inspector:

``` text
AQUAFORGE
────────────────
Machine: Steam Engine
Status: RUNNING

Steam: 420 / 12000 mB
Pressure: 71%
Torque: 12

Network nodes: 18
Load: 72%
────────────────
```

Do not display values that are not actually implemented.

------------------------------------------------------------------------

# 28. Bedrock API assessment

The manifest correctly declares:

``` text
@minecraft/server 2.8.0
@minecraft/server-ui 2.1.0
```

The current event model uses `playerInteractWithBlock`, which is
documented in WorldAfterEvents. citeturn0search14

Scripting V2 uses `world.afterEvents.worldLoad` for world-state access,
replacing the old `worldInitialize` pattern. citeturn1search10

The current API direction is therefore reasonable for the stated target.

Do not migrate to newer APIs merely for novelty. Stability on 1.26.33 /
2.8.0 matters more.

------------------------------------------------------------------------

# 29. Static JSON result

All inspected JSON files parse successfully.

The block texture references match the terrain texture registry.

The block loot references match actual loot-table files.

This is important:

> The current major problems are **runtime architecture problems**, not
> broad JSON corruption.

------------------------------------------------------------------------

# 30. Similar Java technology mods

## Create

Create is the major reference for mechanical engineering and rotational
networks.

Useful principle:

``` text
source
  ↓
transmission
  ↓
consumer
```

Do not reproduce Create's enormous feature set.

Aquaforge should instead deliver:

``` text
compact simulation
+
clear engineering
+
Android performance
+
multiplayer reliability
```

## Mekanism

Mekanism is much broader, with machinery, energy, fluids, gases,
transmitters, factories and high-tier systems. Its official
documentation describes multiple machine tiers and dedicated
transmission systems. citeturn0search0turn0search8turn0search9

Take the architectural lesson:

> Separate resource domains.

For Aquaforge:

``` text
Mechanical
Water
Steam
```

is sufficient.

## Create: Steam 'n' Rails

Create: Steam 'n' Rails demonstrates the value of deeply extending one
coherent subsystem rather than adding unrelated technology.
citeturn0search15

Aquaforge should own:

> **water + mechanical + pressure + steam engineering.**

------------------------------------------------------------------------

# 31. Comparison matrix

  -------------------------------------------------------------------------------------
  Dimension         Aquaforge                Create-style       Mekanism-style
  ----------------- ------------------------ ------------------ -----------------------
  Core focus        Water/mechanical/steam   Rotation/factory   Multi-domain technology

  Network model     Lightweight BFS          Complex rotational Energy/fluid/gas/item
                                             system             networks

  Machine count     Small                    Very large         Very large

  Fluid model       Abstract                 Rich factory       Dedicated fluid/gas
                                             interactions       systems

  Power             Torque abstraction       Rotation/stress    Energy

  Android goal      Explicit                 Not the primary    Not the primary target
                                             target             

  Current maturity  Prototype                Mature Java        Mature Java ecosystem
                                             ecosystem          

  Best              Lightweight engineering  Physical factory   Industrial depth
  differentiator                             expression         
  -------------------------------------------------------------------------------------

------------------------------------------------------------------------

# 32. Technical rating

  -----------------------------------------------------------------------------
  Category                                     Score Assessment
  --------------------- ---------------------------- --------------------------
  Architecture concept                          8/10 Clear domains and bounded
                                                     networks

  Code simplicity                               8/10 Small and understandable

  Android foundation                            8/10 10-tick cadence + cache

  Multiplayer readiness                         4/10 Persistence/transactions
                                                     incomplete

  Fluid simulation                              3/10 Connectivity without
                                                     actual transfer

  Mechanical simulation                         5/10 Sources work; allocation
                                                     incomplete

  Steam simulation                              4/10 Basic source/consumption
                                                     exists

  Machine processing                            2/10 Runtime recipe execution
                                                     missing

  Content foundation                            7/10 Strong small starting set

  Extensibility                                 8/10 Datura architecture is
                                                     promising

  Documentation                                 5/10 Some claims exceed runtime
  accuracy                                           

  **Overall current                         **5/10** Strong prototype; not
  implementation**                                   release-stable
  -----------------------------------------------------------------------------

------------------------------------------------------------------------

# 33. What would make Aquaforge stand out?

Do not compete by adding hundreds of machines.

Make it:

> **The lightweight physical engineering network for Bedrock.**

Identity:

``` text
MECHANICAL
    ↓
WATER
    ↓
PRESSURE
    ↓
STEAM
    ↓
ROTATION
    ↓
INDUSTRIAL PROCESSING
```

## Standout feature 1 --- Real networks

Pipes, pumps, tanks and valves should actually matter.

## Standout feature 2 --- Cheap deterministic failures

``` text
NORMAL
LOW_FLOW
LOW_PRESSURE
OVERPRESSURE
STARVED
BLOCKED
OVERLOAD
```

## Standout feature 3 --- One engineering inspector

Expose:

``` text
nodes
flow
pressure
torque
demand
load
status
```

## Standout feature 4 --- Datura interoperability

Other packs should be able to consume:

``` text
mechanical_power
water_flow
steam_pressure
machine_status
network_status
```

## Standout feature 5 --- Sleeping factories

``` text
Nearby
 → normal simulation

Far away
 → low-frequency simulation

No active work
 → sleep
```

That would be particularly strong for Android.

------------------------------------------------------------------------

# 34. Exact development order

## Patch 0 --- Correctness

``` text
1. Centralize version.
2. Use one machine registry.
3. Implement machine inventories.
4. Implement recipe execution.
5. Implement progress.
6. Implement power consumption.
7. Implement output blocking.
8. Implement persistence.
9. Remove unsafe JSON truncation.
10. Add save schema/migration.
```

## Patch 1 --- Water

``` text
1. Pump extracts water.
2. Pump transfers water.
3. Tank stores water.
4. Pipes transport abstract flow.
5. Turbine consumes flow.
6. Turbine produces torque.
```

## Patch 2 --- Steam

``` text
1. Boiler consumes water.
2. Boiler creates steam.
3. Pipes transfer steam.
4. Regulator limits pressure.
5. Engine consumes steam.
6. Engine creates torque.
7. Condenser returns water.
```

## Patch 3 --- Multiplayer

``` text
1. Deterministic allocation.
2. Network overload.
3. Atomic item transactions.
4. Save/load migration.
5. Concurrent-player testing.
```

## Patch 4 --- Optimization

``` text
1. Remove routine radius discovery.
2. Canonical network IDs.
3. Active machine scheduler.
4. Sleeping networks.
5. Android stress profiling.
```

------------------------------------------------------------------------

# 35. Multiplayer test matrix

  Test                     Required result
  ------------------------ ---------------------------
  Place machine            Registered once
  Break machine            State cleaned
  Reload world             State restored
  Fill tank                Exact amount retained
  Pump water               Correct transfer
  Block pipe               Flow stops
  Boiler                   Water → steam
  Full steam tank          No overflow
  Steam engine             Steam actually consumed
  Steam engine             Torque only after payment
  Machine input            Consumed once
  Machine output           Created once
  Full output              Input not lost
  Two players              No duplication/loss
  \>96 nodes               Explicit overload
  Distant factory          State retained
  Datura absent            Pack remains usable
  Datura present           Capabilities discovered
  Save during processing   Valid state restored
  Corrupt state            Safe recovery

------------------------------------------------------------------------

# 36. Documentation corrections

The README currently describes block/entity persistence more strongly
than the actual implementation supports.

Until the engine is fixed, document the project as:

``` text
Implemented:
- network discovery
- network caching
- basic mechanical output
- tank state model
- UI inspection
- Datura announcement

Prototype:
- machine processing
- fluid transfer
- pressure
- persistent machine state
```

Do not call a system complete simply because its blocks and recipes
exist.

------------------------------------------------------------------------

# 37. Files for the next implementation pass

  -----------------------------------------------------------------------
  File                                Action
  ----------------------------------- -----------------------------------
  `scripts/main.js`                   Main engine correction

  `scripts/datura_bridge.js`          Single Datura protocol layer

  `data.json`                         Convert to active runtime registry
                                      or eliminate duplication

  `README.md`                         Correct implementation claims

  `roadmap.md`                        Update actual state

  `changelog.md`                      Record functional changes

  `blocks/*.json`                     Add only necessary state/inventory
                                      components

  `recipes/*.json`                    Keep compact

  `ui/aquaforge_panel.json`           Expand only after real inspector
                                      data exists
  -----------------------------------------------------------------------

------------------------------------------------------------------------

# 38. Final target architecture

``` text
                  Datura Core
                       │
                capability protocol
                       │
              ┌────────┴────────┐
              │                 │
         Aquaforge          Other Packs
              │
      ┌───────┼────────┐
      │       │        │
 Mechanical  Water   Steam
      │       │        │
      └───────┼────────┘
              │
        Network Solver
              │
        Power Allocation
              │
       Machine Scheduler
              │
        Recipe Processor
              │
       Input → Progress
              │
           Output
              │
       Persistent State
```

## Core design law

> **Do not simulate what the player cannot observe or exploit.**

Do not simulate individual fluid particles if the gameplay consequence
is simply:

``` text
machine receives enough flow
```

Store effective:

``` text
flow
pressure
capacity
demand
```

and expose those values.

That provides technical depth without turning Bedrock into a physics
simulation.

------------------------------------------------------------------------

# 39. Final assessment

Aquaforge v0.17 is a **strong prototype architecture**.

The architecture should **not be thrown away**.

The correct move is to finish the existing engine.

The next work should be:

``` text
INVENTORY
   ↓
RECIPE
   ↓
POWER PAYMENT
   ↓
PROGRESS
   ↓
OUTPUT
   ↓
PERSISTENCE
```

then:

``` text
WATER TRANSFER
   ↓
STEAM TRANSFER
   ↓
PRESSURE
   ↓
DETERMINISTIC NETWORK ALLOCATION
```

Only after these are stable should you add:

-   Steam Turbine;
-   larger tanks;
-   advanced pipes;
-   automation;
-   factories;
-   additional tiers.

The current codebase is small enough that this can be achieved without
over-engineering it.

------------------------------------------------------------------------

# Appendix A --- API references

Microsoft Learn was used to verify the API-specific portions of this
audit:

-   World dynamic properties.
-   Block dynamic properties.
-   WorldAfterEvents / `playerInteractWithBlock`.
-   Scripting V2 / `worldLoad`.
-   Script events / `sendScriptEvent`.

`playerInteractWithBlock` is documented as a WorldAfterEvents event.
citeturn0search14

Scripting V2 documents `worldLoad` as the replacement for the older
world initialization event when accessing world state.
citeturn1search10

Block dynamic properties are documented for block entities and include a
defined storage boundary. citeturn1search2turn1search4

Script-event communication is documented through `sendScriptEvent()` and
`scriptEventReceive`. citeturn1search12turn1search1

# Appendix B --- Comparison references

Mekanism documentation was used for the comparison of machine tiers,
transmitters, energy/fluid/gas architecture and factories.
citeturn0search0turn0search8turn0search9

Create: Steam 'n' Rails was used as a reference for a focused steam/rail
subsystem extension. citeturn0search15

------------------------------------------------------------------------

**Bottom line: keep the architecture, finish the engine, and resist
feature expansion until the existing Mechanical → Water → Steam loop is
deterministic, persistent and multiplayer-safe.**
