# Aquaforge Roadmap

## v1.3.4 — Large geos restored + machine faces (2026-10-13)
- [x] Restore exact large water_wheel / windmill / turbine geos from assets
- [x] Machine multi-face front/side/top/bottom textures
- [x] FINAL_TEXTURES full overlay
- [x] Pipe Molang == 1.0 reliability

## v1.3.3 — Connect/tessellate repair (2026-10-13)
- [x] Pipe connector harden + query.block_state Molang
- [x] Remove OOB water_wheel geo (tessellation fix)
- [x] Pressure gauge full_block multi-face
- [x] Glass fluid tank top face
- [x] Unused texture cleanup

## v1.3.1 — Texture/geo repair & console fixes (2026-10-13)
- [x] Fix fluid_tap invalid bone_visibility (handle_off/on)
- [x] Compact windmill geo within error bounds
- [x] Recipe unlock data for all new shaped recipes
- [x] Overlay AquaForge_Assets geos + UV + item textures
- [x] Remove phase4 placeholders; replace machine placeholder textures
- [x] Rebuild terrain + item atlases

## v1.3.0 — Universal tanks & fluid transport (2026-10-13)
- [x] Rename water_pipe → fluid_pipe; add glass_fluid_pipe
- [x] Copper / iron / steel / glass fluid tanks @ 16 000 mB with pressure tiers
- [x] Remove legacy water_tank + steam_tank
- [x] Integrate new geo models + UV textures (pipes, tanks, fluids, gasses)
- [x] Networks accept any fluid/steam/gas into universal tanks
- [x] Terrain atlas + lang + catalog + recipes updated

## v0.1.0 — Foundation (delivered)
- [x] Mechanical → water → steam progression skeleton
- [x] Water/steam pipes and tanks
- [x] Boiler/steam engine
- [x] Three powered machines
- [x] Persistent block entity state
- [x] Lightweight event-driven simulation
- [x] Android-conscious 10-tick update cadence

## v0.2.0 — Stability
- [x] Replace local-radius discovery with incremental network graph cache
- [ ] Side-aware fluid insertion/extraction
- [x] Proper pump valves and one-way flow
- [ ] Pressure loss by pipe length
- [ ] Steam temperature and condensation rules
- [ ] Machine jam/overpressure protection
- [ ] Multiplayer stress testing

## v0.3.0 — Content
- [ ] Tier II/III tanks and pipes
- [ ] Water turbine governor
- [ ] Steam turbine
- [ ] Boiler fuel efficiency and safety valve
- [ ] More machine recipes
- [ ] Better machine screens

## v1.0.0 — Stable Release
- [ ] Automated regression test plan
- [ ] Save/load migration tests
- [ ] Large-network performance profiling on Android
- [ ] Full documentation
- [ ] Final balance pass

## Audit stabilization (2026-09-24)
- [x] P0.3 Remove JSON truncation on state save
- [x] P0.6 Version source of truth (`VERSION` constant)
- [x] P0.5 Chunk-sharded persistence
- [ ] Placement-primary discovery (reduce player scans)

## Audit P1 (2026-09-24)
- [x] P1.3
- [x] P1.4
- [x] P1.6

## Audit P2 (2026-09-24)
- [x] P2.4 Machine status

## Energy P0 (2026-09-26)
- [x] Connecting water/steam/gas pipes + shaft geometry
- [x] Pipe connector script
- [ ] Valves, gauges, UHV, transformers (later phases)

## Energy P1 (2026-09-26)
- [x] Valves / one-way / fluid tap
- [x] Pressure gauge + speedometer
- [x] Gearbox / wheel / turbine models
- [ ] Custom ogg sound assets
- [ ] UHV / transformers / hyper conduits

## Energy P2 (2026-09-26)
- [x] Mechanical clutch + windmill
- [ ] Hyper conduits (cross-domain)

## Energy P3+ remaining
- [ ] Custom pipe/mech .ogg assets
- [ ] Gauge reads live tank mB from network state (not adjacency proxy)
- [ ] Valve flow gating in fluid simulation

## Energy P4 (2026-09-26)
- [x] Sound framework + interaction cues

## v0.2.0 implementation pass
- [x] Closed valves and fluid taps now gate water/steam network traversal.
- [x] Valve state is respected by cached network discovery.

## Daturion v2.1 — P0 Foundation (2026-09-27)
- [x] Shared MachineRegistry + Network interfaces + Transaction locks delivered in Datura Core 0.0.24
- Domains continue to own simulation; Core provides contracts only

## Daturion v1.2.2 — Phase 1 Transport
- [x] Pipe/shaft visual connection hardening
- [x] Creative item catalog group
- [x] Transparent water pipe texture

## Daturion v1.2.5
- [x] Console menu_category + catalog schema fixes
- [x] Phase 1–4 asset integration (textures/geo/mcstructure)

## Suite 1.26 — Phase 1 console criticals
- [x] Remove deprecated minecraft:custom_components
- [x] Fix geometry identifier mismatches
- [x] Strip invalid Periodix/Veylorn groups
- [x] Catalog schema (icon/name in group_identifier)

## Suite 1.2.7 — Phase 2 polish
- [x] Silence unused CC warnings (event-only connectors)
- [x] Portal version string alignment
- [x] Explicit @minecraft/server 2.8.0 deps
- [x] Phase 1 verification retained

## Suite 1.2.8 — Phase 3 connection harden
- [x] Verify Phase 1+2 retained
- [x] Change-only permutation updates for pipes/cables
- [x] Face states + min_engine_version reaffirmed

## Suite 1.2.9 — Phase 4 polish
- [x] Verify Phase 1–3
- [x] Veylorn grave_storage client entity
- [x] Group lang keys
- [x] Pipe/cable render polish

## Suite 1.2.10 — Phase 5
- [x] Verify Phase 1–4
- [x] Validator recipe soft-warn fixed
- [x] Event-only connector docs
