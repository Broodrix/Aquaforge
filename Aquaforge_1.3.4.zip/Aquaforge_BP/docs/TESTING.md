# Aquaforge — In-Game Testing Guide (v0.1.22)

## Creative group
Open Creative → Construction → **Aquaforge Machinery** group.

## Mechanical chain (Age 3)
1. Place **Hand Crank** or **Water Wheel** (wheel needs flowing water adjacent).
2. Place **Shaft** against the source — shaft should grow a connector toward the source.
3. Place **Gearbox** on the shaft line.
4. Place **Mechanical Mill** or **Hydraulic Press** on the output side.
5. Right-click Hand Crank to input torque; mill/press should receive power (action bar / particles when active).

**What connects to what**
| Block | Connects to |
|-------|-------------|
| Shaft | shaft, gearbox, hand crank, water wheel, water turbine, steam engine, mill, press, hammer, clutch, windmill, speedometer |
| Water pipe | water pipe, water tank, water pump, water turbine, boiler, condenser, valve, one-way valve, fluid tap, hydraulic press |
| Steam pipe | steam pipe, steam tank, boiler, steam engine, pressure regulator, steam hammer, condenser, valve, one-way valve, pressure gauge |
| Gas pipe | gas pipe, valve, one-way valve |

## Steam loop (Age 4)
1. **Water Tank** → **Water Pipe** → **Boiler** (fuel + water).
2. Boiler → **Steam Pipe** → **Steam Engine** → **Shaft** → machines.
3. Optional: **Condenser** returns water to tank; **Pressure Regulator** / **Pressure Gauge** on steam line.

## Visual check
- Place two pipes adjacent → both should show connecting arms.
- Break middle pipe → neighbors retract arms within ~2 ticks.
