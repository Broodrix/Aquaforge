import { world, system, ItemStack } from "@minecraft/server";
import { registerPipeConnector } from "./pipe_connector.js";
import { registerDevices } from "./devices.js";
import { ActionFormData } from "@minecraft/server-ui";
import { showMachineWindow } from "./ui/machineWindow.js";
import { getMachineUiDef } from "./ui/machineUiDefs.js";

registerPipeConnector();
registerDevices();

const NS = "aquaforge";
const VERSION = "1.3.4";
const TICK = 10;
const MAX_NODES = 2048;
const MAX_NET_CACHE = 128;
const NODE = new Set();
/** @type {Set<string>} machines with work this cycle */
const ACTIVE = new Set();
/** @type {Map<string, { keys: string[], kind: string, builtAt: number }>} */
const networkCache = new Map();
const dirtyNetworks = new Set();
const MECH = new Set(["shaft","gearbox","hand_crank","water_wheel","water_pump","water_turbine","steam_engine","mechanical_mill","hydraulic_press","steam_hammer"]);
const WATER = new Set(["valve", "fluid_tap", "fluid_pipe", "glass_fluid_pipe", "copper_tank", "iron_tank", "steel_tank", "glass_fluid_tank", "water_pump", "water_turbine", "boiler", "hydraulic_press", "condenser"]);
const STEAM = new Set(["valve", "fluid_tap", "steam_pipe", "copper_tank", "iron_tank", "steel_tank", "glass_fluid_tank", "boiler", "steam_engine", "pressure_regulator", "steam_hammer", "condenser"]);
const GAS = new Set(["valve", "fluid_tap", "gas_pipe", "copper_tank", "iron_tank", "steel_tank", "glass_fluid_tank"]);
const MACHINES = new Set(["mechanical_mill","hydraulic_press","steam_hammer"]);
const SOURCES = new Set(["hand_crank","water_wheel","water_turbine","steam_engine"]);
const DIRS=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];

const TECH_STATE_KEY = "tech_tree:state_v1";
const TECH_GATES = {
  hand_crank: null,
  water_wheel: "daturion:water_power",
  water_pump: "daturion:water_power",
  water_turbine: "daturion:water_power",
  boiler: "daturion:steam_power",
  steam_engine: "daturion:steam_power",
  steam_hammer: "daturion:steam_power",
  hydraulic_press: "daturion:mechanical_power",
  mechanical_mill: "daturion:mechanical_power"
};

/** In-memory cache of datura:tech:cache — avoids JSON.parse of full faction state. */
let _techCache = null;
let _techCacheTick = -1;
const TECH_CACHE_KEY = "datura:tech:cache";

function refreshTechCache() {
  try {
    const raw = world.getDynamicProperty(TECH_CACHE_KEY);
    if (typeof raw === "string" && raw) {
      const c = JSON.parse(raw);
      if (c && Array.isArray(c.u)) {
        _techCache = new Set(c.u);
        _techCacheTick = system.currentTick;
        return;
      }
    }
  } catch {}
  // Fallback: full state (legacy)
  try {
    const raw = world.getDynamicProperty(TECH_STATE_KEY);
    if (typeof raw === "string" && raw) {
      const state = JSON.parse(raw);
      _techCache = new Set(state?.unlocked_techs || []);
      _techCacheTick = system.currentTick;
      return;
    }
  } catch {}
  _techCache = null; // fail-open
}

function isTechUnlocked(techId) {
  if (!techId) return true;
  if (!_techCache || system.currentTick - _techCacheTick > 40) refreshTechCache();
  if (!_techCache) return true; // Tech Tree absent
  return _techCache.has(techId);
}


function idOf(block){ return block?.typeId?.startsWith(NS+":") ? block.typeId.slice(NS.length+1) : ""; }
function key(dim,p){ return `${dim.id}|${Math.floor(p.x)}|${Math.floor(p.y)}|${Math.floor(p.z)}`; }
function locKey(p){ return `${Math.floor(p.x)},${Math.floor(p.y)},${Math.floor(p.z)}`; }

/** Script-side machine state (block_entity DP unsupported on this format_version). */
/** @type {Map<string, Record<string, number>>} */
const STATE = new Map();
const STATE_LEGACY = "aquaforge:state_v1";
const STATE_INDEX = "aquaforge:shard_index";
const STATE_PREFIX = "aquaforge:c:";
const MAX_SHARD_CHARS = 28000;
const MAX_TOTAL_ENTRIES = 1024;
let stateDirty = false;

function afChunkId(k) {
  // key format: dimId|x|y|z
  try {
    const parts = String(k).split("|");
    const dim = (parts[0] || "minecraft:overworld").replace(/[^a-z0-9_:]/gi, "_");
    const x = Math.floor(Number(parts[1]) || 0);
    const z = Math.floor(Number(parts[3]) || 0);
    return `${dim}:${Math.floor(x / 16)}:${Math.floor(z / 16)}`;
  } catch { return "unknown:0:0"; }
}
function afShardKey(cid) { return STATE_PREFIX + cid; }

function loadState() {
  try {
    const indexRaw = world.getDynamicProperty(STATE_INDEX);
    if (typeof indexRaw === "string" && indexRaw) {
      const index = JSON.parse(indexRaw);
      if (Array.isArray(index)) {
        for (const cid of index) {
          try {
            const raw = world.getDynamicProperty(afShardKey(cid));
            if (typeof raw !== "string" || !raw) continue;
            const obj = JSON.parse(raw);
            if (!obj || typeof obj !== "object") continue;
            for (const [k, v] of Object.entries(obj)) {
              if (v && typeof v === "object") STATE.set(k, v);
            }
          } catch (e) { console.warn("[Aquaforge] shard load " + cid + ": " + e); }
        }
        return;
      }
    }
    // Legacy single-blob migration
    const raw = world.getDynamicProperty(STATE_LEGACY);
    if (typeof raw !== "string" || !raw) return;
    const obj = JSON.parse(raw);
    if (!obj || typeof obj !== "object") return;
    for (const [k, v] of Object.entries(obj)) {
      if (v && typeof v === "object") STATE.set(k, v);
    }
    stateDirty = true; // rewrite as shards
  } catch {}
}

function saveState() {
  if (!stateDirty) return;
  stateDirty = false;
  try {
    /** @type {Map<string, Record<string, object>>} */
    const byChunk = new Map();
    let n = 0;
    for (const [k, v] of STATE) {
      if (n >= MAX_TOTAL_ENTRIES) break;
      const cid = afChunkId(k);
      let obj = byChunk.get(cid);
      if (!obj) { obj = {}; byChunk.set(cid, obj); }
      obj[k] = v;
      n++;
    }
    const index = [];
    for (const [cid, obj] of byChunk) {
      const payload = JSON.stringify(obj);
      if (payload.length > MAX_SHARD_CHARS) {
        console.warn("[Aquaforge] shard " + cid + " too large (" + payload.length + "); skip");
        continue;
      }
      world.setDynamicProperty(afShardKey(cid), payload);
      index.push(cid);
    }
    world.setDynamicProperty(STATE_INDEX, JSON.stringify(index));
    try { world.setDynamicProperty(STATE_LEGACY, undefined); } catch {}
  } catch (e) {
    console.warn("[Aquaforge] saveState: " + e);
  }
}

function getDP(block, name, def = 0) {
  try {
    const k = key(block.dimension, block.location);
    const row = STATE.get(k);
    if (row && row[name] !== undefined) return row[name];
  } catch {}
  return def;
}

function setDP(block, name, value) {
  try {
    const k = key(block.dimension, block.location);
    let row = STATE.get(k);
    if (!row) { row = {}; STATE.set(k, row); }
    row[name] = value;
    stateDirty = true;
  } catch {}
}

function clearStateAt(dim, p) {
  const k = key(dim, p);
  if (STATE.delete(k)) stateDirty = true;
}

function getTank(block, fluid) { return Number(getDP(block, fluid, 0)); }
function setTank(block, fluid, value, cap) { setDP(block, fluid, Math.max(0, Math.min(cap, value))); }
function isNode(block,kind){ const id=idOf(block); return kind.has(id); }
function valveOpen(block){
  const id=idOf(block);
  if(id!=="valve" && id!=="fluid_tap") return true;
  try { return !!block.permutation.getState("aquaforge:open"); } catch { return true; }
}
function neighbors(dim,p){ return DIRS.map(d=>({x:p.x+d[0],y:p.y+d[1],z:p.z+d[2]})); }

function connected(dim,start,kind,limit=96){
  const q=[start], seen=new Set([locKey(start)]), out=[];
  let head = 0;
  while(head < q.length && out.length < limit){
    const p = q[head++];
    const b = dim.getBlock(p);
    if(!b || !isNode(b,kind) || !valveOpen(b)) continue;
    out.push(b);
    for(const n of neighbors(dim,p)){
      const k = locKey(n);
      if(seen.has(k)) continue;
      const nb = dim.getBlock(n);
      if(nb && isNode(nb,kind) && valveOpen(nb)){ seen.add(k); q.push(n); }
    }
  }
  return out;
}

/** Cached network: rebuild only when dirty. */
function getCachedNetwork(dim, start, kind, kindName, limit=96){
  const ck = `${key(dim,start)}|${kindName}`;
  if (dirtyNetworks.has(ck) || dirtyNetworks.has(key(dim,start))) {
    networkCache.delete(ck);
    dirtyNetworks.delete(ck);
    dirtyNetworks.delete(key(dim,start));
  }
  const hit = networkCache.get(ck);
  if (hit) {
    // Rehydrate blocks from keys
    const blocks = [];
    for (const k of hit.keys) {
      const parts = k.split("|");
      if (parts.length < 4) continue;
      try {
        const b = dim.getBlock({ x:+parts[1], y:+parts[2], z:+parts[3] });
        if (b && isNode(b, kind)) blocks.push(b);
      } catch {}
    }
    if (blocks.length) return blocks;
    networkCache.delete(ck);
  }
  const nodes = connected(dim, start, kind, limit);
  if (networkCache.size >= MAX_NET_CACHE) {
    const first = networkCache.keys().next().value;
    if (first) networkCache.delete(first);
  }
  networkCache.set(ck, {
    keys: nodes.map(b => key(dim, b.location)),
    kind: kindName,
    builtAt: system.currentTick
  });
  return nodes;
}

function getMechanical(dim,start){
  const nodes=getCachedNetwork(dim,start,MECH,"MECH",96); let power=0;
  for(const b of nodes){
    const id=idOf(b);
    if(id==="hand_crank") power+=Number(getDP(b,"boost",0));
    else if(id==="water_wheel") power+=6*waterWheelStrength(b);
    else if(id==="water_turbine") power+=Number(getDP(b,"mech_out",0));
    else if(id==="steam_engine") power+=Number(getDP(b,"mech_out",0));
  }
  return {nodes,power};
}

function waterWheelStrength(b){
  try{
    const dim=b.dimension, p=b.location;
    let water=0;
    for(const d of DIRS){ const n=dim.getBlock({x:p.x+d[0],y:p.y+d[1],z:p.z+d[2]}); if(n&&(n.typeId==="minecraft:water"||n.typeId==="minecraft:flowing_water")) water++; }
    return Math.min(4,water);
  }catch{return 1;}
}

function pressure(b){ return Math.min(100, Math.floor(getTank(b,"steam")/120)); }

function markDirty(dim,p){
  const k=key(dim,p);
  dirtyNetworks.add(k);
  // Localized: only invalidate cache entries that include this node
  for (const [ck, entry] of [...networkCache]) {
    if (!ck.startsWith(dim.id + "|")) continue;
    if (entry.keys && entry.keys.includes(k)) {
      networkCache.delete(ck);
      dirtyNetworks.add(ck);
    } else if (ck.startsWith(k + "|")) {
      // cache key is start|KIND for this exact node
      networkCache.delete(ck);
      dirtyNetworks.add(ck);
    }
  }
  // Also invalidate this node as a network seed for all kinds
  for (const kindName of ["MECH", "STEAM", "WATER"]) {
    networkCache.delete(k + "|" + kindName);
    dirtyNetworks.add(k + "|" + kindName);
  }
}

function pruneStaleNodes(){
  // Active-interest: keep nodes near any player; drop distant first when over cap
  if(NODE.size<=MAX_NODES) return;
  const interest = new Set();
  try {
    for (const player of world.getAllPlayers()) {
      const dim = player.dimension;
      const bx = Math.floor(player.location.x);
      const by = Math.floor(player.location.y);
      const bz = Math.floor(player.location.z);
      for (const k of NODE) {
        const parts = k.split("|");
        if (parts.length < 4) continue;
        if (parts[0] !== dim.id) continue;
        const x = +parts[1], y = +parts[2], z = +parts[3];
        if (Math.abs(x - bx) <= 32 && Math.abs(y - by) <= 16 && Math.abs(z - bz) <= 32) {
          interest.add(k);
        }
      }
    }
  } catch {}
  const excess = NODE.size - MAX_NODES;
  let removed = 0;
  for (const k of NODE) {
    if (removed >= excess) break;
    if (interest.has(k)) continue; // protect active-interest
    NODE.delete(k);
    networkCache.delete(k);
    dirtyNetworks.delete(k);
    removed++;
  }
  // If still over cap, hard-drop oldest remaining
  if (NODE.size > MAX_NODES) {
    for (const k of NODE) {
      if (NODE.size <= MAX_NODES) break;
      NODE.delete(k);
      networkCache.delete(k);
      dirtyNetworks.delete(k);
    }
  }
}

function registerLoadedNodesAroundPlayers(){
  for(const player of world.getAllPlayers()){
    const dim=player.dimension;
    const base={x:Math.floor(player.location.x),y:Math.floor(player.location.y),z:Math.floor(player.location.z)};
    for(let dy=-2;dy<=2;dy++) for(let dx=-6;dx<=6;dx++) for(let dz=-6;dz<=6;dz++){
      try{
        const b=dim.getBlock({x:base.x+dx,y:base.y+dy,z:base.z+dz});
        const id=idOf(b);
        if(id) NODE.add(key(dim,b.location));
      }catch{}
    }
  }
  pruneStaleNodes();
}

function tickHydraulics(){
  const seen=new Set();
  for(const k of Array.from(NODE)){
    if(seen.has(k)) continue;
    const parts=k.split("|");
    if(parts.length<4){ NODE.delete(k); continue; }
    const dimId=parts[0], x=+parts[1], y=+parts[2], z=+parts[3];
    let dim,b;
    try{ dim=world.getDimension(dimId); b=dim.getBlock({x,y,z}); }catch{ NODE.delete(k); continue; }
    if(!b){ NODE.delete(k); continue; }
    const id=idOf(b);
    if(!id){ NODE.delete(k); continue; }
    seen.add(k);

    try{
      if(id==="boiler"){
        const water=getTank(b,"water");
        if(water>=10){
          setTank(b,"water",water-10,8000);
          const steamNodes=getCachedNetwork(dim,{x,y,z},STEAM,"STEAM",48);
          for(const sb of steamNodes){
            if(["copper_tank","iron_tank","steel_tank","glass_fluid_tank","boiler"].includes(idOf(sb))){
              setTank(sb,"steam",getTank(sb,"steam")+8,12000);
            }
          }
        }
      } else if(id==="steam_engine"){
        const steamNodes=getCachedNetwork(dim,{x,y,z},STEAM,"STEAM",32);
        let steamAvail=0;
        for(const sb of steamNodes) steamAvail+=getTank(sb,"steam");
        if(steamAvail>=5){
          let need=5;
          for(const sb of steamNodes){
            if(need<=0) break;
            const have=getTank(sb,"steam");
            const take=Math.min(have,need);
            setTank(sb,"steam",have-take,12000);
            need-=take;
          }
          setDP(b,"mech_out",12);
          try { system.sendScriptEvent("aquaforge:mech_out", JSON.stringify({ x, y, z, dimId, torque: 12 })); } catch {}
        } else {
          setDP(b,"mech_out",0);
        }
      } else if(id==="water_turbine"){
        setDP(b,"mech_out",waterWheelStrength(b)*4);
      } else if(id==="hand_crank"){
        const boost=Number(getDP(b,"boost",0));
        if(boost>0) setDP(b,"boost",Math.max(0,boost-1));
      } else if(MACHINES.has(id)){
        const {power}=getMechanical(dim,{x,y,z});
        if(power>=4){ setDP(b,"active",1); setDP(b,"status",1); } else { setDP(b,"active",0); setDP(b,"status",0); } // 1=RUNNING 0=NO_POWER
      }
    }catch{ NODE.delete(k); }
  }
}

function showPanel(player){
  const form=new ActionFormData().title("Aquaforge").body("Water & Steam Engineering\n\nCached network core · dirty rebuild.");
  form.button("System Status").button("Close");
  form.show(player).then(r=>{
    if(r.canceled||r.selection===1) return;
    showSystems(player);
  }).catch(()=>{});
}

function showSystems(player){
  const dim=player.dimension;
  let text="";
  const seen=new Set();
  for(let dy=-3;dy<=3;dy++) for(let dx=-8;dx<=8;dx++) for(let dz=-8;dz<=8;dz++){
    try{
      const b=dim.getBlock({x:Math.floor(player.location.x)+dx,y:Math.floor(player.location.y)+dy,z:Math.floor(player.location.z)+dz});
      if(!b) continue;
      const id=idOf(b);
      if(!id||seen.has(locKey(b.location))) continue;
      if(id==="copper_tank"||id==="iron_tank"||id==="steel_tank"||id==="glass_fluid_tank"){
        const cap=16000; const pr=id==="steel_tank"?20:id==="iron_tank"?12:id==="copper_tank"?8:4;
        text+=`${id.replace(/_/g," ")}: ${getTank(b,"fluid")}/${cap} mB  max ${pr} bar\n`;
      }
      
      if(id==="steam_engine") text+=`Steam Engine: ${getDP(b,"mech_out",0)} torque\n`;
      seen.add(locKey(b.location));
    }catch{}
  }
  new ActionFormData().title("Aquaforge • Systems").body(text||"No active systems nearby.").button("Close").show(player).catch(()=>{});
}

world.afterEvents.playerPlaceBlock.subscribe(e=>{
  const id=idOf(e.block);
  if(id){
    NODE.add(key(e.dimension,e.block.location));
    markDirty(e.dimension,e.block.location);
  }
});
world.afterEvents.playerBreakBlock.subscribe(e=>{
  const k=key(e.dimension,e.block.location);
  clearStateAt(e.dimension,e.block.location);
  NODE.delete(k);
  networkCache.delete(k);
  dirtyNetworks.delete(k);
  markDirty(e.dimension,e.block.location);
});
world.afterEvents.itemUse.subscribe(e=>{if(e.itemStack?.typeId==="aquaforge:control_panel")showPanel(e.source);});
world.afterEvents.playerInteractWithBlock.subscribe(e=>{
  const id=idOf(e.block); if(!id)return;
  const gate = TECH_GATES[id];
  if (gate && !isTechUnlocked(gate)) {
    try { e.player.sendMessage(`§e[Aquaforge] Requires research: ${gate.replace("daturion:", "")}`); } catch {}
    return;
  }
  if(id==="hand_crank"){setDP(e.block,"boost",Number(getDP(e.block,"boost",0))+8);e.player.sendMessage("§7Hand crank engaged: +8 torque stored.");}
  const TANK_IDS=new Set(["copper_tank","iron_tank","steel_tank","glass_fluid_tank"]);
  if(TANK_IDS.has(id) && e.itemStack?.typeId==="minecraft:water_bucket"){
    const have=getTank(e.block,"fluid"); if(have<=15000){setTank(e.block,"fluid",have+1000,16000); e.player.sendMessage("§bTank filled: +1000 mB");}
  }
  if(TANK_IDS.has(id)||id==="boiler"||id==="steam_engine"||MACHINES.has(id)) showBlockInfo(e.player,e.block);
});
function showBlockInfo(player,b){
  const id = idOf(b);
  const typeId = b.typeId;
  const uiDef = getMachineUiDef(typeId);
  if (uiDef) {
    const live = {
      energy: {
        water: Number(getTank(b, "water") || 0),
        steam: Number(getTank(b, "steam") || 0),
        mechanical: Number(getDP(b, "mech_out", 0) || getDP(b, "boost", 0) || 0),
        hydraulic: Number(pressure(b) || 0),
        heat: id === "boiler" ? Math.min(100, Number(getTank(b, "water") > 0 ? 50 : 0)) : 0
      },
      progress: 0,
      status: (Number(getDP(b, "mech_out", 0)) > 0 || Number(getTank(b, "steam") || 0) > 0) ? "ACTIVE" : "IDLE",
      lines: [`§8Node §f${id}`]
    };
    showMachineWindow(player, uiDef, live).catch(() => {});
    return;
  }
  let body = `Block: ${id}\n\n`;
  if (id === "iron_tank") body += `Water: ${getTank(b,"water")}/8000 mB`;
  else if (id === "steel_tank") body += `Steam: ${getTank(b,"steam")}/12000 mB\nPressure: ${pressure(b)}%`;
  else if (id === "boiler") body += `Water: ${getTank(b,"water")} mB\nSteam network is adjacent.`;
  else if (id === "steam_engine") body += `Output: ${getDP(b,"mech_out",0)} torque`;
  else body += "Use its inventory for processing.";
  new ActionFormData().title(`Aquaforge • ${id}`).body(body).button("Close").show(player).catch(() => {});
}


let _afTickCount = 0;
const _origTickHydraulics = tickHydraulics;
function tickHydraulicsWrapped() {
  const t0 = Date.now();
  _origTickHydraulics();
  _afTickCount++;
  if (_afTickCount % 20 === 0) {
    try {
      world.setDynamicProperty("datura:telemetry:aquaforge", JSON.stringify({
        nodes: NODE.size, active: ACTIVE.size, cache: networkCache.size,
        ms: Date.now() - t0, tick: system.currentTick
      }));
    } catch {}
  }
}

system.runInterval(tickHydraulicsWrapped,TICK);
system.runInterval(registerLoadedNodesAroundPlayers,100);
system.runInterval(pruneStaleNodes,200);
world.afterEvents.worldLoad.subscribe(()=>{ system.runTimeout(()=>{
  try { world.sendMessage(`§bAquaforge§r v${VERSION} · cached networks · mech bridge`); } catch {}
  try { system.sendScriptEvent("aquaforge:pack_ready", JSON.stringify({ version: VERSION })); } catch {}
  try {
    const payload = {
      id: "aquaforge", version: VERSION, protocol: 1,
      capabilities: ["power","mechanical","steam"], tick: system.currentTick
    };
    world.setDynamicProperty("datura:pack:aquaforge", JSON.stringify(payload));
    let index = [];
    try { index = JSON.parse(String(world.getDynamicProperty("datura:protocol:index") || "[]")); } catch { index = []; }
    if (!Array.isArray(index)) index = [];
    if (!index.includes("aquaforge")) {
      index.push("aquaforge");
      world.setDynamicProperty("datura:protocol:index", JSON.stringify(index));
    }
    system.sendScriptEvent("datura:protocol:pack_announced", JSON.stringify(payload));
  } catch {}
},1); });
