/** Aquaforge audio — Energy P4 */
export function playAt(block, id, pitch = 1) {
  if (!block) return;
  try {
    block.dimension.playSound(id, block.location, { pitch, volume: 1 });
  } catch {
    try {
      block.dimension.playSound(id, {
        x: block.location.x + 0.5,
        y: block.location.y + 0.5,
        z: block.location.z + 0.5
      }, { pitch });
    } catch {}
  }
}

export function playValve(block, open) {
  playAt(block, open ? "aquaforge.valve.open" : "aquaforge.valve.close");
}

export function playClutch(block, engaged) {
  playAt(block, engaged ? "aquaforge.clutch.engage" : "aquaforge.clutch.disengage");
}

export function playGauge(block) {
  playAt(block, "aquaforge.gauge.click", 1.3);
}
