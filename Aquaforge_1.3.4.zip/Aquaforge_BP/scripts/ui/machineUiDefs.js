/**
 * Canonical Machine UI definitions for all live domain machines.
 * Domains may override liveState; structure stays here as single source of truth.
 */

/** @type {Record<string, import("./machineWindow.js").MachineUiDef>} */
export const MACHINE_UI_DEFS = {
  // ─── Blue Power ───────────────────────────────────────────
  "blue_power:hand_dynamo": {
    id: "blue_power:hand_dynamo",
    title: "Hand Dynamo",
    subtitle: "Manual kinetic → electric",
    domain: "blue_power",
    energy: "electric",
    energyBars: [{ type: "electric", max: 2000, unit: "GU", label: "Buffer" }],
    actions: [{ id: "crank", label: "§e⚡ Crank (+energy)" }],
    infoLines: ["Hold interact or use action to generate GU."]
  },
  "blue_power:coal_generator": {
    id: "blue_power:coal_generator",
    title: "Coal Generator",
    subtitle: "Combustion → grid power",
    domain: "blue_power",
    energy: "coal",
    energyBars: [
      { type: "electric", max: 2000, unit: "GU", label: "Output Buffer" },
      { type: "coal", max: 200, unit: "fuel", label: "Fuel" }
    ],
    inputSlots: [{ index: 0, label: "Coal / Fuel", role: "fuel" }],
    actions: [{ id: "status", label: "§7Refresh Status" }],
    infoLines: ["Feed coal while interacting to refuel."]
  },
  "blue_power:battery": {
    id: "blue_power:battery",
    title: "Battery",
    subtitle: "Grid energy storage",
    domain: "blue_power",
    energy: "electric",
    energyBars: [{ type: "electric", max: 20000, unit: "GU", label: "Stored" }],
    infoLines: ["Accepts GU from cables / generators."]
  },
  "blue_power:test_machine": {
    id: "blue_power:test_machine",
    title: "Test Machine",
    subtitle: "Power consumer / progress demo",
    domain: "blue_power",
    energy: "electric",
    energyBars: [{ type: "electric", max: 1000, unit: "GU", label: "Buffer" }],
    progress: { max: 100, label: "Work Progress", unit: "%" },
    infoLines: ["Consumes GU to advance progress."]
  },
  "blue_power:transformer": {
    id: "blue_power:transformer",
    title: "Transformer",
    subtitle: "LV ↔ UHV step",
    domain: "blue_power",
    energy: "electric",
    energyBars: [{ type: "electric", max: 512, unit: "GU", label: "Throughput" }],
    actions: [{ id: "toggle_mode", label: "§e⇄ Toggle Step-Up / Step-Down" }],
    infoLines: ["Mode 0 = step-down UHV→LV · Mode 1 = step-up LV→UHV"]
  },
  "blue_power:cable": {
    id: "blue_power:cable",
    title: "Power Cable",
    subtitle: "LV transfer",
    domain: "blue_power",
    energy: "electric",
    energyBars: [{ type: "electric", max: 64, unit: "GU/t", label: "Transfer Rate" }],
    infoLines: ["Connects generators, batteries, machines."]
  },
  "blue_power:uhv_cable": {
    id: "blue_power:uhv_cable",
    title: "UHV Cable",
    subtitle: "High-voltage transfer",
    domain: "blue_power",
    energy: "electric",
    energyBars: [{ type: "electric", max: 512, unit: "GU/t", label: "Transfer Rate" }]
  },
  "blue_power:hyper_conduit": {
    id: "blue_power:hyper_conduit",
    title: "Hyper Conduit",
    subtitle: "Hyper-era energy bus",
    domain: "blue_power",
    energy: "hyper",
    energyBars: [{ type: "hyper", max: 2048, unit: "HU/t", label: "Hyper Flow" }]
  },
  "blue_power:warp_conduit": {
    id: "blue_power:warp_conduit",
    title: "Warp Conduit",
    subtitle: "Warp-era energy bus",
    domain: "blue_power",
    energy: "warp",
    energyBars: [{ type: "warp", max: 4096, unit: "WU/t", label: "Warp Flow" }]
  },
  "blue_power:jump_conduit": {
    id: "blue_power:jump_conduit",
    title: "Jump Conduit",
    subtitle: "Jump-era energy bus",
    domain: "blue_power",
    energy: "jump",
    energyBars: [{ type: "jump", max: 8192, unit: "JE/t", label: "Jump Flow" }]
  },
  "blue_power:alloy_furnace": {
    id: "blue_power:alloy_furnace",
    title: "Alloy Furnace",
    subtitle: "Dual-input electric smelting",
    domain: "blue_power",
    energy: "electric",
    energyBars: [{ type: "electric", max: 4000, unit: "GU", label: "Buffer" }],
    progress: { max: 100, label: "Smelt Progress", unit: "%" },
    inputSlots: [
      { index: 0, label: "Input A", role: "input" },
      { index: 1, label: "Input B", role: "input" }
    ],
    outputSlots: [{ index: 2, label: "Output", role: "output" }],
    actions: [{ id: "open_legacy", label: "§eOpen Detailed UI" }]
  },
  "blue_power:analyzer": {
    id: "blue_power:analyzer",
    title: "Grid Analyzer",
    subtitle: "Network diagnostics",
    domain: "blue_power",
    energy: "electric",
    infoLines: ["Hold and use on a block or in air for factory overview."]
  },

  // ─── Aquaforge ────────────────────────────────────────────
  "aquaforge:hand_crank": {
    id: "aquaforge:hand_crank",
    title: "Hand Crank",
    subtitle: "Manual mechanical power",
    domain: "aquaforge",
    energy: "mechanical",
    energyBars: [{ type: "mechanical", max: 64, unit: "RPM", label: "Output" }],
    actions: [{ id: "crank", label: "§e⚙ Turn Crank" }]
  },
  "aquaforge:water_wheel": {
    id: "aquaforge:water_wheel",
    title: "Water Wheel",
    subtitle: "Flow → torque",
    domain: "aquaforge",
    energy: "water",
    energyBars: [
      { type: "mechanical", max: 128, unit: "RPM", label: "Shaft Output" },
      { type: "water", max: 1000, unit: "mB", label: "Flow" }
    ]
  },
  "aquaforge:water_turbine": {
    id: "aquaforge:water_turbine",
    title: "Water Turbine",
    subtitle: "Pressurized hydro power",
    domain: "aquaforge",
    energy: "hydraulic",
    energyBars: [
      { type: "mechanical", max: 256, unit: "RPM", label: "Shaft Output" },
      { type: "hydraulic", max: 16, unit: "bar", label: "Pressure" }
    ]
  },
  "aquaforge:water_pump": {
    id: "aquaforge:water_pump",
    title: "Water Pump",
    subtitle: "Moves fluid through pipes",
    domain: "aquaforge",
    energy: "mechanical",
    energyBars: [
      { type: "mechanical", max: 64, unit: "RPM", label: "Drive" },
      { type: "water", max: 1000, unit: "mB", label: "Throughput" }
    ]
  },
  "aquaforge:boiler": {
    id: "aquaforge:boiler",
    title: "Boiler",
    subtitle: "Water + heat → steam",
    domain: "aquaforge",
    energy: "steam",
    energyBars: [
      { type: "steam", max: 1000, unit: "kPa", label: "Steam" },
      { type: "water", max: 1000, unit: "mB", label: "Water" },
      { type: "heat", max: 100, unit: "%", label: "Heat" }
    ],
    inputSlots: [{ index: 0, label: "Fuel", role: "fuel" }],
    infoLines: ["Requires water network + fuel heat."]
  },
  "aquaforge:steam_engine": {
    id: "aquaforge:steam_engine",
    title: "Steam Engine",
    subtitle: "Steam → mechanical",
    domain: "aquaforge",
    energy: "steam",
    energyBars: [
      { type: "steam", max: 1000, unit: "kPa", label: "Steam In" },
      { type: "mechanical", max: 256, unit: "RPM", label: "Shaft Out" }
    ]
  },
  "aquaforge:steam_hammer": {
    id: "aquaforge:steam_hammer",
    title: "Steam Hammer",
    subtitle: "Steam-powered forming",
    domain: "aquaforge",
    energy: "steam",
    energyBars: [{ type: "steam", max: 800, unit: "kPa", label: "Steam" }],
    progress: { max: 100, label: "Strike Cycle", unit: "%" },
    inputSlots: [{ index: 0, label: "Workpiece", role: "input" }],
    outputSlots: [{ index: 1, label: "Product", role: "output" }]
  },
  "aquaforge:hydraulic_press": {
    id: "aquaforge:hydraulic_press",
    title: "Hydraulic Press",
    subtitle: "Pressure forming",
    domain: "aquaforge",
    energy: "hydraulic",
    energyBars: [{ type: "hydraulic", max: 20, unit: "bar", label: "Pressure" }],
    progress: { max: 100, label: "Press Cycle", unit: "%" },
    inputSlots: [{ index: 0, label: "Blank", role: "input" }],
    outputSlots: [{ index: 1, label: "Pressed Part", role: "output" }]
  },
  "aquaforge:mechanical_mill": {
    id: "aquaforge:mechanical_mill",
    title: "Mechanical Mill",
    subtitle: "Crush / grind",
    domain: "aquaforge",
    energy: "mechanical",
    energyBars: [{ type: "mechanical", max: 128, unit: "RPM", label: "Drive" }],
    progress: { max: 100, label: "Mill Progress", unit: "%" },
    inputSlots: [{ index: 0, label: "Feed", role: "input" }],
    outputSlots: [{ index: 1, label: "Output", role: "output" }]
  },
  "aquaforge:copper_tank": {
    id: "aquaforge:copper_tank",
    title: "Copper Tank",
    subtitle: "Universal 16 bucket · 8 bar",
    domain: "aquaforge",
    energy: "fluid",
    energyBars: [{ type: "fluid", max: 16000, unit: "mB", label: "Stored" }]
  },
  "aquaforge:iron_tank": {
    id: "aquaforge:iron_tank",
    title: "Iron Tank",
    subtitle: "Universal 16 bucket · 12 bar",
    domain: "aquaforge",
    energy: "fluid",
    energyBars: [{ type: "fluid", max: 16000, unit: "mB", label: "Stored" }]
  },
  "aquaforge:steel_tank": {
    id: "aquaforge:steel_tank",
    title: "Steel Tank",
    subtitle: "Universal 16 bucket · 20 bar",
    domain: "aquaforge",
    energy: "fluid",
    energyBars: [{ type: "fluid", max: 16000, unit: "mB", label: "Stored" }]
  },
  "aquaforge:glass_fluid_tank": {
    id: "aquaforge:glass_fluid_tank",
    title: "Glass Fluid Tank",
    subtitle: "Transparent 16 bucket · 4 bar",
    domain: "aquaforge",
    energy: "fluid",
    energyBars: [{ type: "fluid", max: 16000, unit: "mB", label: "Stored" }]
  },
  "aquaforge:pressure_gauge": {
    id: "aquaforge:pressure_gauge",
    title: "Pressure Gauge",
    subtitle: "Network pressure readout",
    domain: "aquaforge",
    energy: "hydraulic",
    energyBars: [{ type: "hydraulic", max: 20, unit: "bar", label: "Reading" }]
  },
  "aquaforge:speedometer": {
    id: "aquaforge:speedometer",
    title: "Speedometer",
    subtitle: "Shaft RPM readout",
    domain: "aquaforge",
    energy: "mechanical",
    energyBars: [{ type: "mechanical", max: 256, unit: "RPM", label: "Reading" }]
  },
  "aquaforge:valve": {
    id: "aquaforge:valve",
    title: "Valve",
    subtitle: "Flow control",
    domain: "aquaforge",
    energy: "water",
    actions: [{ id: "toggle", label: "§eOpen / Close" }],
    infoLines: ["Gates fluid network traversal when closed."]
  },
  "aquaforge:one_way_valve": {
    id: "aquaforge:one_way_valve",
    title: "One-Way Valve",
    subtitle: "Check valve",
    domain: "aquaforge",
    energy: "water",
    infoLines: ["Allows flow in one direction only."]
  },
  "aquaforge:condenser": {
    id: "aquaforge:condenser",
    title: "Condenser",
    subtitle: "Steam → water",
    domain: "aquaforge",
    energy: "steam",
    energyBars: [
      { type: "steam", max: 1000, unit: "kPa", label: "Steam In" },
      { type: "water", max: 1000, unit: "mB", label: "Water Out" }
    ]
  },
  "aquaforge:pressure_regulator": {
    id: "aquaforge:pressure_regulator",
    title: "Pressure Regulator",
    subtitle: "Steam pressure control",
    domain: "aquaforge",
    energy: "steam",
    energyBars: [{ type: "steam", max: 1000, unit: "kPa", label: "Setpoint" }]
  },
  "aquaforge:gearbox": {
    id: "aquaforge:gearbox",
    title: "Gearbox",
    subtitle: "Torque / speed conversion",
    domain: "aquaforge",
    energy: "mechanical",
    energyBars: [{ type: "mechanical", max: 256, unit: "RPM", label: "Shaft" }]
  },
  "aquaforge:shaft": {
    id: "aquaforge:shaft",
    title: "Shaft",
    subtitle: "Mechanical transfer",
    domain: "aquaforge",
    energy: "mechanical",
    energyBars: [{ type: "mechanical", max: 128, unit: "RPM", label: "RPM" }]
  },
  "aquaforge:windmill": {
    id: "aquaforge:windmill",
    title: "Windmill",
    subtitle: "Wind → torque",
    domain: "aquaforge",
    energy: "mechanical",
    energyBars: [{ type: "mechanical", max: 96, unit: "RPM", label: "Output" }]
  },
  "aquaforge:mechanical_clutch": {
    id: "aquaforge:mechanical_clutch",
    title: "Mechanical Clutch",
    subtitle: "Engage / disengage shaft",
    domain: "aquaforge",
    energy: "mechanical",
    actions: [{ id: "toggle", label: "§eEngage / Disengage" }]
  },
  "aquaforge:fluid_tap": {
    id: "aquaforge:fluid_tap",
    title: "Fluid Tap",
    subtitle: "Extract / insert fluid",
    domain: "aquaforge",
    energy: "water",
    energyBars: [{ type: "water", max: 1000, unit: "mB", label: "Flow" }]
  }
};

/**
 * @param {string} typeId
 * @returns {import("./machineWindow.js").MachineUiDef | null}
 */
export function getMachineUiDef(typeId) {
  if (!typeId) return null;
  return MACHINE_UI_DEFS[typeId] || null;
}

export function listMachineUiIds() {
  return Object.keys(MACHINE_UI_DEFS);
}
