/**
 * Daturion Power Palette — sci-fi energy colors for machine UI bars.
 * Source: Energy_Colors.md / gui_colors.md (suite Dynamic GUI).
 * § codes approximate hex for ActionForm text rendering on Android.
 */

/** @type {Record<string, { hex: string, argb: string, section: string, name: string }>} */
export const POWER_PALETTE = {
  hyper:       { hex: "#00E5FF", argb: "#FF00E5FF", section: "§b", name: "Electric Cyan" },
  warp:        { hex: "#2979FF", argb: "#FF2979FF", section: "§9", name: "Deep Cobalt" },
  jump:        { hex: "#651FFF", argb: "#FF651FFF", section: "§5", name: "Deep Indigo" },
  coal:        { hex: "#FF6D00", argb: "#FFFF6D00", section: "§6", name: "Blaze Orange" },
  mechanical:  { hex: "#B0BEC5", argb: "#FFB0BEC5", section: "§7", name: "Polished Steel" },
  hydraulic:   { hex: "#00B0FF", argb: "#FF00B0FF", section: "§b", name: "Vivid Sky Blue" },
  water:       { hex: "#00B0FF", argb: "#FF00B0FF", section: "§b", name: "Vivid Sky Blue" },
  steam:       { hex: "#ECEFF1", argb: "#FFECEFF1", section: "§f", name: "Vapor White" },
  electric:    { hex: "#FFEA00", argb: "#FFFFEA00", section: "§e", name: "Neon Yellow" },
  combustion:  { hex: "#FF3D00", argb: "#FFFF3D00", section: "§c", name: "Engine Crimson" },
  gas:         { hex: "#A7FFEB", argb: "#FFA7FFEB", section: "§a", name: "Oxygen Teal" },
  progress:    { hex: "#69F0AE", argb: "#FF69F0AE", section: "§a", name: "Process Green" },
  heat:        { hex: "#FF8A65", argb: "#FFFF8A65", section: "§6", name: "Thermal Coral" },
  nuclear:     { hex: "#76FF03", argb: "#FF76FF03", section: "§a", name: "Reactor Lime" },
  fusion:      { hex: "#18FFFF", argb: "#FF18FFFF", section: "§b", name: "Plasma Cyan" }
};

export function getPowerColor(key) {
  return POWER_PALETTE[key] || POWER_PALETTE.mechanical;
}

export function sectionFor(key) {
  return getPowerColor(key).section;
}
