/**
 * Dynamic Machine Window Builder — Datura Core
 * Android-first: ActionFormData (proven on 1.26.33 / Galaxy A06).
 * Definition-driven: one builder serves all domain machines.
 * CustomForm/Observable path reserved behind feature-detect (not required).
 *
 * Architecture: domains gather liveState → showMachineWindow(player, def, liveState)
 * Cross-pack: portable; Core hosts canonical copy + textures in Core RP.
 */
import { ActionFormData } from "@minecraft/server-ui";
import { getPowerColor, sectionFor } from "./powerColors.js";

const BAR_WIDTH = 20;

/**
 * @typedef {Object} SlotDef
 * @property {number} index
 * @property {string} label
 * @property {string} [role] input|output|fuel|catalyst
 */

/**
 * @typedef {Object} EnergyBarDef
 * @property {string} type  mechanical|hydraulic|steam|electric|hyper|warp|jump|coal|gas|combustion
 * @property {number} max
 * @property {string} [unit]
 * @property {string} [label]
 */

/**
 * @typedef {Object} ProgressBarDef
 * @property {number} max
 * @property {string} [label]
 * @property {string} [unit]
 */

/**
 * @typedef {Object} MachineUiDef
 * @property {string} id
 * @property {string} title
 * @property {string} [subtitle]
 * @property {string} domain
 * @property {string} [energy] primary energy key for header tint
 * @property {SlotDef[]} [inputSlots]
 * @property {SlotDef[]} [outputSlots]
 * @property {EnergyBarDef[]} [energyBars]
 * @property {ProgressBarDef} [progress]
 * @property {string[]} [infoLines]
 * @property {Array<{ id: string, label: string }>} [actions]
 */

/**
 * @typedef {Object} LiveState
 * @property {Record<string, number>} [energy]  type → current
 * @property {number} [progress]
 * @property {string[]} [lines] extra status lines
 * @property {Record<number, string>} [slotHints] slot index → item name/count
 * @property {string} [status] IDLE|RUNNING|JAMMED|NO_POWER|...
 */

/**
 * Render a 20-char energy/progress bar with power-palette section codes.
 * @param {number} current
 * @param {number} max
 * @param {string} unit
 * @param {string} colorKey
 */
export function renderBar(current, max, unit = "", colorKey = "electric") {
  const m = Math.max(1, Number(max) || 1);
  const c = Math.max(0, Math.min(m, Number(current) || 0));
  const ratio = c / m;
  const filled = Math.round(ratio * BAR_WIDTH);
  const empty = BAR_WIDTH - filled;
  const sec = sectionFor(colorKey);
  const bar = "█".repeat(filled) + "░".repeat(empty);
  const unitStr = unit ? ` §8${unit}` : "";
  return `§7[${sec}${bar}§7] §f${Math.round(c)}§7/§f${Math.round(m)}${unitStr}`;
}

/**
 * Build body text for a machine window from definition + live state.
 * @param {MachineUiDef} def
 * @param {LiveState} [live]
 */
export function buildMachineBody(def, live = {}) {
  const lines = [];
  const energyKey = def.energy || "electric";
  const tint = sectionFor(energyKey);

  lines.push(`${tint}§l${def.title}§r`);
  if (def.subtitle) lines.push(`§7${def.subtitle}`);
  if (live.status) lines.push(`§8Status: §f${live.status}`);
  lines.push("§8────────────────────────");

  // Energy bars
  const bars = def.energyBars || [];
  if (bars.length) {
    lines.push("§l§6Energy");
    for (const bar of bars) {
      const cur = live.energy?.[bar.type] ?? live.energy?.[bar.type + "_current"] ?? 0;
      const label = bar.label || labelForEnergy(bar.type);
      lines.push(`§7${label}`);
      lines.push(renderBar(cur, bar.max, bar.unit || unitFor(bar.type), bar.type));
    }
    lines.push("§8────────────────────────");
  }

  // Progress
  if (def.progress) {
    const cur = live.progress ?? 0;
    lines.push(`§l§a${def.progress.label || "Progress"}`);
    lines.push(renderBar(cur, def.progress.max, def.progress.unit || "%", "progress"));
    lines.push("§8────────────────────────");
  }

  // Slots
  const inputs = def.inputSlots || [];
  const outputs = def.outputSlots || [];
  if (inputs.length || outputs.length) {
    if (inputs.length) {
      lines.push("§l§bInput");
      for (const s of inputs) {
        const hint = live.slotHints?.[s.index];
        const mark = hint ? "§a●" : "§8○";
        lines.push(`  ${mark} §f${s.label} §8#${s.index}${hint ? ` §7${hint}` : ""}`);
      }
    }
    if (outputs.length) {
      lines.push("§l§dOutput");
      for (const s of outputs) {
        const hint = live.slotHints?.[s.index];
        const mark = hint ? "§a●" : "§8○";
        lines.push(`  ${mark} §f${s.label} §8#${s.index}${hint ? ` §7${hint}` : ""}`);
      }
    }
    lines.push("§8────────────────────────");
  }

  // Extra lines from domain
  if (Array.isArray(live.lines) && live.lines.length) {
    for (const L of live.lines) lines.push(String(L));
  }
  if (Array.isArray(def.infoLines)) {
    for (const L of def.infoLines) lines.push(`§8${L}`);
  }

  // Texture hint (RP provides frame; ActionForm cannot host custom BG — documented)
  lines.push("§8[Datura Machine UI]");

  return lines.join("\n");
}

function labelForEnergy(type) {
  const map = {
    mechanical: "Mechanical (RPM)",
    hydraulic: "Hydraulic Pressure",
    water: "Water Flow",
    steam: "Steam Pressure",
    electric: "Electric (GU)",
    hyper: "Hyper (HU)",
    warp: "Warp (WU)",
    jump: "Jump (JE)",
    coal: "Coal Fuel",
    combustion: "Combustion",
    gas: "Gas Pressure",
    heat: "Heat",
    nuclear: "Nuclear",
    fusion: "Fusion"
  };
  return map[type] || type;
}

function unitFor(type) {
  const map = {
    mechanical: "RPM",
    hydraulic: "bar",
    water: "mB",
    steam: "kPa",
    electric: "GU",
    hyper: "HU",
    warp: "WU",
    jump: "JE",
    coal: "ticks",
    combustion: "GU",
    gas: "kPa",
    heat: "K",
    progress: "%"
  };
  return map[type] || "";
}

/**
 * Show definition-driven machine window.
 * @param {import("@minecraft/server").Player} player
 * @param {MachineUiDef} def
 * @param {LiveState} [live]
 * @param {Array<{ id: string, label: string, run?: Function }>} [extraActions]
 * @returns {Promise<{ canceled: boolean, actionId?: string }>}
 */
export async function showMachineWindow(player, def, live = {}, extraActions = []) {
  if (!player || !def) return { canceled: true };

  const body = buildMachineBody(def, live);
  const form = new ActionFormData().title(`§8${def.title}`).body(body);

  const actions = [];
  // Domain-provided actions first
  for (const a of def.actions || []) {
    actions.push(a);
    form.button(a.label);
  }
  for (const a of extraActions || []) {
    actions.push(a);
    form.button(a.label);
  }
  form.button("§7Close");

  try {
    const res = await form.show(player);
    if (res.canceled || res.selection === undefined) return { canceled: true };
    if (res.selection >= actions.length) return { canceled: false, actionId: "close" };
    const chosen = actions[res.selection];
    if (chosen?.run) {
      try { await chosen.run(player); } catch (_) {}
    }
    return { canceled: false, actionId: chosen?.id || String(res.selection) };
  } catch (e) {
    try { console.warn(`[MachineUI] show failed: ${e}`); } catch (_) {}
    return { canceled: true };
  }
}

export const MachineWindowBuilder = {
  renderBar,
  buildMachineBody,
  show: showMachineWindow
};
