/**
 * Aquaforge — Transport visual connector
 * Face states + Molang bone_visibility. Event place/break + deferred refresh (Android-safe).
 * No minecraft:custom_components.
 */
import { world, system } from "@minecraft/server";

const NS = "aquaforge";

const PIPE_TYPES = new Set([
  "aquaforge:fluid_pipe",
  "aquaforge:glass_fluid_pipe",
  "aquaforge:steam_pipe",
  "aquaforge:gas_pipe",
  "aquaforge:shaft"
]);

const CONNECT_TYPES = new Set([
  ...PIPE_TYPES,
  "aquaforge:valve",
  "aquaforge:one_way_valve",
  "aquaforge:fluid_tap",
  "aquaforge:mechanical_clutch",
  "aquaforge:windmill",
  "aquaforge:copper_tank",
  "aquaforge:iron_tank",
  "aquaforge:steel_tank",
  "aquaforge:glass_fluid_tank",
  "aquaforge:water_pump",
  "aquaforge:water_turbine",
  "aquaforge:boiler",
  "aquaforge:steam_engine",
  "aquaforge:condenser",
  "aquaforge:pressure_regulator",
  "aquaforge:mechanical_mill",
  "aquaforge:hydraulic_press",
  "aquaforge:steam_hammer",
  "aquaforge:gearbox",
  "aquaforge:hand_crank",
  "aquaforge:water_wheel",
  "aquaforge:pressure_gauge",
  "aquaforge:speedometer"
]);

const DIRS = [
  { face: "north", dx: 0, dy: 0, dz: -1 },
  { face: "south", dx: 0, dy: 0, dz: 1 },
  { face: "east", dx: 1, dy: 0, dz: 0 },
  { face: "west", dx: -1, dy: 0, dz: 0 },
  { face: "up", dx: 0, dy: 1, dz: 0 },
  { face: "down", dx: 0, dy: -1, dz: 0 }
];

function canConnect(selfType, neighborType) {
  if (!neighborType || !CONNECT_TYPES.has(neighborType)) return false;
  if (selfType === "aquaforge:shaft") {
    return (
      neighborType === "aquaforge:shaft" ||
      neighborType === "aquaforge:gearbox" ||
      neighborType === "aquaforge:hand_crank" ||
      neighborType === "aquaforge:water_wheel" ||
      neighborType === "aquaforge:water_turbine" ||
      neighborType === "aquaforge:steam_engine" ||
      neighborType === "aquaforge:mechanical_mill" ||
      neighborType === "aquaforge:hydraulic_press" ||
      neighborType === "aquaforge:steam_hammer" ||
      neighborType === "aquaforge:mechanical_clutch" ||
      neighborType === "aquaforge:windmill" ||
      neighborType === "aquaforge:speedometer"
    );
  }
  if (selfType === "aquaforge:fluid_pipe" || selfType === "aquaforge:glass_fluid_pipe") {
    return (
      neighborType === "aquaforge:fluid_pipe" ||
      neighborType === "aquaforge:glass_fluid_pipe" ||
      neighborType === "aquaforge:copper_tank" ||
      neighborType === "aquaforge:iron_tank" ||
      neighborType === "aquaforge:steel_tank" ||
      neighborType === "aquaforge:glass_fluid_tank" ||
      neighborType === "aquaforge:water_pump" ||
      neighborType === "aquaforge:water_turbine" ||
      neighborType === "aquaforge:boiler" ||
      neighborType === "aquaforge:condenser" ||
      neighborType === "aquaforge:valve" ||
      neighborType === "aquaforge:one_way_valve" ||
      neighborType === "aquaforge:fluid_tap" ||
      neighborType === "aquaforge:hydraulic_press" ||
      neighborType === "aquaforge:pressure_gauge"
    );
  }
  if (selfType === "aquaforge:steam_pipe") {
    return (
      neighborType === "aquaforge:steam_pipe" ||
      neighborType === "aquaforge:copper_tank" ||
      neighborType === "aquaforge:iron_tank" ||
      neighborType === "aquaforge:steel_tank" ||
      neighborType === "aquaforge:glass_fluid_tank" ||
      neighborType === "aquaforge:boiler" ||
      neighborType === "aquaforge:steam_engine" ||
      neighborType === "aquaforge:pressure_regulator" ||
      neighborType === "aquaforge:steam_hammer" ||
      neighborType === "aquaforge:condenser" ||
      neighborType === "aquaforge:valve" ||
      neighborType === "aquaforge:one_way_valve" ||
      neighborType === "aquaforge:pressure_gauge"
    );
  }
  if (selfType === "aquaforge:gas_pipe") {
    return (
      neighborType === "aquaforge:gas_pipe" ||
      neighborType === "aquaforge:copper_tank" ||
      neighborType === "aquaforge:iron_tank" ||
      neighborType === "aquaforge:steel_tank" ||
      neighborType === "aquaforge:glass_fluid_tank" ||
      neighborType === "aquaforge:valve" ||
      neighborType === "aquaforge:one_way_valve"
    );
  }
  return PIPE_TYPES.has(neighborType);
}

export function updatePipeConnections(block) {
  if (!block || !PIPE_TYPES.has(block.typeId)) return;
  try {
    let perm = block.permutation;
    const selfType = block.typeId;
    const dim = block.dimension;
    const loc = block.location;
    let changed = false;
    for (const d of DIRS) {
      let neighbor = null;
      try {
        neighbor = dim.getBlock({
          x: loc.x + d.dx,
          y: loc.y + d.dy,
          z: loc.z + d.dz
        });
      } catch {
        neighbor = null;
      }
      const ok = !!(neighbor && canConnect(selfType, neighbor.typeId));
      const stateName = `${NS}:${d.face}`;
      try {
        const cur = perm.getState(stateName);
        if (cur !== ok) {
          perm = perm.withState(stateName, ok);
          changed = true;
        }
      } catch {
        try {
          perm = perm.withState(stateName, ok);
          changed = true;
        } catch {}
      }
    }
    if (changed) {
      block.setPermutation(perm);
    }
  } catch (e) {
    console.warn("[Aquaforge] pipe update: " + (e?.message || e));
  }
}

function refreshNeighbors(block) {
  if (!block) return;
  const dim = block.dimension;
  const loc = block.location;
  for (const d of DIRS) {
    try {
      const n = dim.getBlock({
        x: loc.x + d.dx,
        y: loc.y + d.dy,
        z: loc.z + d.dz
      });
      if (n && PIPE_TYPES.has(n.typeId)) updatePipeConnections(n);
    } catch {}
  }
}

function scheduleRefresh(block) {
  if (!block) return;
  const dim = block.dimension;
  const loc = { x: block.location.x, y: block.location.y, z: block.location.z };
  const typeId = block.typeId;
  const run = () => {
    try {
      const b = dim.getBlock(loc);
      if (!b) return;
      if (PIPE_TYPES.has(b.typeId)) {
        updatePipeConnections(b);
        refreshNeighbors(b);
      } else if (CONNECT_TYPES.has(b.typeId) || CONNECT_TYPES.has(typeId)) {
        refreshNeighbors(b);
      }
    } catch {}
  };
  // Immediate + deferred passes (Android event ordering)
  system.run(run);
  system.runTimeout(run, 1);
  system.runTimeout(run, 3);
}

let registered = false;
export function registerPipeConnector() {
  if (registered) return;
  registered = true;

  try {
    world.afterEvents.playerPlaceBlock.subscribe((e) => {
      try {
        if (PIPE_TYPES.has(e.block.typeId) || CONNECT_TYPES.has(e.block.typeId)) {
          scheduleRefresh(e.block);
        }
      } catch {}
    });
  } catch {}

  try {
    world.afterEvents.playerBreakBlock.subscribe((e) => {
      try {
        const loc = e.block.location;
        const dim = e.dimension ?? e.block.dimension;
        const run = () => {
          for (const d of DIRS) {
            try {
              const n = dim.getBlock({
                x: loc.x + d.dx,
                y: loc.y + d.dy,
                z: loc.z + d.dz
              });
              if (n && PIPE_TYPES.has(n.typeId)) updatePipeConnections(n);
            } catch {}
          }
        };
        system.run(run);
        system.runTimeout(run, 1);
        system.runTimeout(run, 3);
      } catch {}
    });
  } catch {}
}
