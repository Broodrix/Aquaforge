import { playValve, playClutch, playGauge } from "./audio.js";
/**
 * Aquaforge P1 — valves, taps, gauges.
 */
import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { showMachineWindow } from "./ui/machineWindow.js";
import { getMachineUiDef } from "./ui/machineUiDefs.js";

const VALVE_TYPES = new Set(["aquaforge:valve", "aquaforge:fluid_tap"]);
const GAUGE_TYPES = new Set(["aquaforge:pressure_gauge", "aquaforge:speedometer"]);

const CLUTCH = "aquaforge:mechanical_clutch";

function toggleEngaged(block) {
  try {
    const perm = block.permutation;
    const on = !!perm.getState("aquaforge:engaged");
    block.setPermutation(perm.withState("aquaforge:engaged", !on));
    return !on;
  } catch { return null; }
}


const DIRS = [
  { dx: 0, dy: 0, dz: -1 },
  { dx: 0, dy: 0, dz: 1 },
  { dx: 1, dy: 0, dz: 0 },
  { dx: -1, dy: 0, dz: 0 },
  { dx: 0, dy: 1, dz: 0 },
  { dx: 0, dy: -1, dz: 0 }
];

function toggleOpen(block) {
  try {
    const perm = block.permutation;
    const open = !!perm.getState("aquaforge:open");
    block.setPermutation(perm.withState("aquaforge:open", !open));
    return !open;
  } catch {
    return null;
  }
}

function neighborSummary(block) {
  const dim = block.dimension;
  const loc = block.location;
  const lines = [];
  let water = 0, steam = 0, mech = 0;
  for (const d of DIRS) {
    try {
      const n = dim.getBlock({ x: loc.x + d.dx, y: loc.y + d.dy, z: loc.z + d.dz });
      if (!n || !n.typeId.startsWith("aquaforge:")) continue;
      const id = n.typeId.replace("aquaforge:", "");
      lines.push("§7- §f" + id);
    } catch {}
  }
  return lines;
}

/** Read fluid/mech proxies from adjacent tanks via world DP state map if exposed — lightweight scan. */
function readAdjacentTanks(block) {
  // Import STATE access is internal to main.js; use dynamic property row keys if present
  const dim = block.dimension;
  const loc = block.location;
  let water = 0, steam = 0, samples = 0;
  for (const d of DIRS) {
    try {
      const n = dim.getBlock({ x: loc.x + d.dx, y: loc.y + d.dy, z: loc.z + d.dz });
      if (!n) continue;
      const tid = n.typeId;
      if (tid === "aquaforge:copper_tank" || tid === "aquaforge:iron_tank" || tid === "aquaforge:steel_tank" || tid === "aquaforge:glass_fluid_tank" || tid === "aquaforge:boiler") {
        // Best-effort: message layer uses getTank in main; here show adjacency only
        samples++;
        water += 1;
      }
      if (tid === "aquaforge:copper_tank" || tid === "aquaforge:iron_tank" || tid === "aquaforge:steel_tank" || tid === "aquaforge:glass_fluid_tank" || tid === "aquaforge:boiler" || tid === "aquaforge:steam_engine") {
        samples++;
        steam += 1;
      }
    } catch {}
  }
  return { water, steam, samples };
}

export async function openPressureGauge(player, block) {
  try {
    const def = getMachineUiDef("aquaforge:pressure_gauge");
    if (def) {
      const adj = neighborSummary(block);
      const live = {
        energy: { hydraulic: Math.min(def.energyBars?.[0]?.max || 20, Math.max(0, adj.length * 3)) },
        status: adj.length ? "LINKED" : "ISOLATED",
        lines: adj.slice(0, 8)
      };
      await showMachineWindow(player, def, live);
      return;
    }
  } catch (_) {}

  const adj = neighborSummary(block);
  const tanks = readAdjacentTanks(block);
  let body = "§bPRESSURE GAUGE\n§8--------------------------------\n";
  body += `§fAdjacent aquaforge nodes: §b${adj.length}\n`;
  body += `§fWater-side links: §b${tanks.water}\n`;
  body += `§fSteam-side links: §b${tanks.steam}\n`;
  if (adj.length) {
    body += "§8--------------------------------\n";
    body += adj.slice(0, 8).join("\n") + "\n";
  }
  body += "§8--------------------------------\n§7Place next to tanks/pipes for network insight.";
  try {
    await new ActionFormData().title("§bPressure Gauge").body(body).button("Close").show(player);
  } catch {}
}

export async function openSpeedometer(player, block) {
  try {
    const def = getMachineUiDef("aquaforge:speedometer");
    if (def) {
      const adj = neighborSummary(block);
      const live = {
        energy: { mechanical: Math.min(def.energyBars?.[0]?.max || 20, Math.max(0, adj.length * 3)) },
        status: adj.length ? "LINKED" : "ISOLATED",
        lines: adj.slice(0, 8)
      };
      await showMachineWindow(player, def, live);
      return;
    }
  } catch (_) {}

  const adj = neighborSummary(block);
  let body = "§bSPEEDOMETER\n§8--------------------------------\n";
  body += `§fAdjacent nodes: §b${adj.length}\n`;
  const mech = adj.filter((l) =>
    /shaft|gearbox|wheel|turbine|engine|mill|press|hammer|crank/.test(l)
  );
  body += `§fMechanical links: §b${mech.length}\n`;
  // RPM proxy: more mechanical neighbors ≈ higher network activity (display only)
  const rpmProxy = mech.length * 60;
  body += `§fEst. shaft activity: §b${rpmProxy} §7(proxy units)\n`;
  if (adj.length) {
    body += "§8--------------------------------\n";
    body += adj.slice(0, 8).join("\n") + "\n";
  }
  body += "§8--------------------------------\n§7Proxy readout — not a physics tachometer.";
  try {
    await new ActionFormData().title("§bSpeedometer").body(body).button("Close").show(player);
  } catch {}
}

let registered = false;
export function registerDevices() {
  if (registered) return;
  registered = true;

    // custom components removed — playerInteractWithBlock is sole path (1.26)

  // Fallback interact
  try {
    world.afterEvents.playerInteractWithBlock.subscribe((e) => {
      try {
        const id = e.block?.typeId;
        if (id === CLUTCH) {
          const now = toggleEngaged(e.block);
          if (now !== null) { try { playClutch(e.block, now); } catch {} e.player.sendMessage(now ? "§aClutch ENGAGED" : "§6Clutch DISENGAGED"); }
        } else if (VALVE_TYPES.has(id)) {
          const nowOpen = toggleOpen(e.block);
          if (nowOpen !== null) {
            try { playValve(e.block, nowOpen); } catch {}
            e.player.sendMessage(nowOpen ? "§aValve OPEN" : "§6Valve CLOSED");
          }
        } else if (id === "aquaforge:pressure_gauge") {
          system.run(() => { try { playGauge(e.block); } catch {} openPressureGauge(e.player, e.block); });
        } else if (id === "aquaforge:speedometer") {
          system.run(() => { try { playGauge(e.block); } catch {} openSpeedometer(e.player, e.block); });
        }
      } catch {}
    });
  } catch {}
}
