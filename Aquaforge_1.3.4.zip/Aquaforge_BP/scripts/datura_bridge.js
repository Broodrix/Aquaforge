/**
 * Datura cross-pack bridge (no Core import — works standalone).
 * Contract matches Datura Core protocol / integration.
 */
import { world, system } from "@minecraft/server";

const PACK_KEY = (id) => `datura:pack:${id}`;
const CAP_KEY = (cap) => `datura:capability:${cap}`;
const INDEX_KEY = "datura:protocol:index";

function safeSet(key, value) {
  try {
    world.setDynamicProperty(key, value);
    return true;
  } catch {
    return false;
  }
}

function safeGet(key, def = null) {
  try {
    const v = world.getDynamicProperty(key);
    return v === undefined ? def : v;
  } catch {
    return def;
  }
}

export function announcePack(id, version, capabilities = []) {
  const payload = {
    id: String(id),
    version: String(version ?? "0.0.0"),
    protocol: 1,
    capabilities: (capabilities || []).map(String),
    tick: system.currentTick
  };
  safeSet(PACK_KEY(id), JSON.stringify(payload));
  let index = [];
  try {
    index = JSON.parse(String(safeGet(INDEX_KEY, "[]") || "[]"));
  } catch {
    index = [];
  }
  if (!Array.isArray(index)) index = [];
  if (!index.includes(id)) {
    index.push(id);
    safeSet(INDEX_KEY, JSON.stringify(index));
  }
  for (const cap of payload.capabilities) {
    let owners = [];
    try {
      owners = JSON.parse(String(safeGet(CAP_KEY(cap), "[]") || "[]"));
    } catch {
      owners = [];
    }
    if (!Array.isArray(owners)) owners = [];
    if (!owners.includes(id)) {
      owners.push(id);
      safeSet(CAP_KEY(cap), JSON.stringify(owners));
    }
  }
  emitDatura("pack_ready", { id, version: payload.version, capabilities: payload.capabilities });
  return true;
}

export function hasCapability(cap) {
  try {
    const owners = JSON.parse(String(safeGet(CAP_KEY(cap), "[]") || "[]"));
    return Array.isArray(owners) && owners.length > 0;
  } catch {
    return false;
  }
}

export function emitDatura(eventName, payload = {}) {
  const name = String(eventName).replace(/^datura:/, "").replace(/:/g, "_");
  const msg = JSON.stringify({ ...payload, _tick: system.currentTick }).slice(0, 2000);
  try {
    system.sendScriptEvent(`datura:${name}`, msg);
  } catch {
    /* optional */
  }
  safeSet(`datura:event:${name}:last`, msg.slice(0, 1800));
}

export function onDatura(eventName, handler) {
  const want = String(eventName).replace(/^datura:/, "").replace(/:/g, "_");
  try {
    system.afterEvents?.scriptEventReceive?.subscribe?.((ev) => {
      try {
        if (!ev.id || !String(ev.id).startsWith("datura:")) return;
        const name = String(ev.id).slice("datura:".length);
        if (name !== want && name.replace(/_/g, ":") !== eventName) return;
        let payload = {};
        try {
          payload = ev.message ? JSON.parse(ev.message) : {};
        } catch {
          payload = { raw: String(ev.message || "") };
        }
        handler(payload, ev);
      } catch {
        /* isolate */
      }
    });
  } catch {
    /* no script events */
  }
}

